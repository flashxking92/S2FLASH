"""
VCFight V3 - Session Management Commands
/addsession, /delsession, /status, /setrecordgroup
"""

import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from config.settings import is_sudo, is_owner, OWNER_ID, RECORD_GROUP, LOGGER_GROUP

logger = logging.getLogger(__name__)


class SessionCommands:
    def __init__(self, bot: Client, assistant_manager, db, health):
        self.bot = bot
        self.assistant_manager = assistant_manager
        self.db = db
        self.health = health
        self.record_group = RECORD_GROUP
        self.register_handlers()

    def register_handlers(self):

        @self.bot.on_message(filters.command("addsession") & filters.private)
        async def addsession_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!** Only sudo users can add sessions.")

            if len(message.command) < 2:
                return await message.reply(
                    "**🔑 Add Session**\n\n"
                    "Usage: `/addsession SESSION_STRING`\n\n"
                    "**How to get session string:**\n"
                    "1. Run `python gen_string.py`\n"
                    "2. Enter your API ID and API Hash\n"
                    "3. Login with the assistant account's phone number\n"
                    "4. Copy the session string\n\n"
                    "**Example:** `/addsession AQGj8Mk...`"
                )

            session_string = message.text.split(None, 1)[1].strip()
            status_msg = await message.reply("⏳ **Adding session...**")

            try:
                result = await self.assistant_manager.add_assistant(session_string)

                if result:
                    self.db.save_assistant(
                        session_string, result['name'],
                        result['user_id'], result.get('username')
                    )
                    self.health.increment_commands()

                    await status_msg.edit(
                        f"✅ **Session Added Successfully!**\n\n"
                        f"**Name:** {result['name']}\n"
                        f"**Username:** @{result.get('username', 'N/A')}\n"
                        f"**User ID:** `{result['user_id']}`\n\n"
                        f"**Next Steps:**\n"
                        f"1. Add @{result.get('username', 'assistant')} to both groups\n"
                        f"2. Make the assistant admin\n"
                        f"3. Use `/join` in the target group VC\n"
                        f"4. Use `/record` to start the bridge"
                    )

                    # Log to logger group
                    try:
                        await client.send_message(
                            LOGGER_GROUP,
                            f"✅ **New Session Added**\n\n"
                            f"**Name:** {result['name']}\n"
                            f"**ID:** `{result['user_id']}`\n"
                            f"**Added by:** {message.from_user.mention}"
                        )
                    except:
                        pass
                else:
                    await status_msg.edit("❌ **Failed to add session!** Invalid or revoked session string.")

            except Exception as e:
                await status_msg.edit(f"❌ **Error:** `{str(e)[:200]}`")
                logger.error(f"addsession error: {e}")

        @self.bot.on_message(filters.command("delsession") & filters.private)
        async def delsession_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if self.assistant_manager.get_assistant_count() == 0:
                return await message.reply("❌ **No sessions to delete!**")

            # Show available sessions
            assistants = self.assistant_manager.get_all_assistants()
            if len(message.command) < 2:
                text = "**🗑 Delete Session**\n\n**Available Sessions:**\n\n"
                for i, ass in enumerate(assistants, 1):
                    text += f"{i}. **{ass['name']}** - `{ass['user_id']}`\n"
                text += "\nUsage: `/delsession USER_ID`"
                return await message.reply(text)

            try:
                user_id = int(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid user ID!")

            status_msg = await message.reply("⏳ **Removing session...**")

            if await self.assistant_manager.remove_assistant(user_id):
                self.db.remove_assistant(user_id)
                self.health.increment_commands()
                await status_msg.edit(f"✅ **Session removed:** `{user_id}`")
            else:
                await status_msg.edit(f"❌ **Session not found:** `{user_id}`")

        @self.bot.on_message(filters.command("status"))
        async def status_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            self.health.increment_commands()

            # Session status
            assistants = self.assistant_manager.get_all_assistants()
            session_text = f"**📋 VCFight V3 Status**\n\n"
            session_text += f"**Sessions:** `{len(assistants)}`\n\n"

            if assistants:
                for i, ass in enumerate(assistants, 1):
                    active_chats = len(ass.get('active_chats', []))
                    session_text += (
                        f"{i}. **{ass['name']}** (@{ass.get('username', 'N/A')})\n"
                        f"   ID: `{ass['user_id']}` | Active VCs: `{active_chats}`\n\n"
                    )
            else:
                session_text += "⚠️ No sessions added!\n\n"

            session_text += f"**Record Group:** `{self.record_group}`\n"
            session_text += f"**Logger Group:** `{LOGGER_GROUP}`\n"

            await message.reply(session_text)

        @self.bot.on_message(filters.command("setrecordgroup") & filters.group)
        async def setrecordgroup_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            if len(message.command) < 2:
                return await message.reply(
                    f"**Current Record Group:** `{self.record_group}`\n\n"
                    "Usage: `/setrecordgroup CHAT_ID`"
                )

            try:
                new_group = int(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid chat ID!")

            self.record_group = new_group
            self.health.increment_commands()
            await message.reply(f"✅ **Record group set to:** `{new_group}`")
