"""
VCFight V3 - Owner Only Commands
/addsudo, /delsudo, /listsudo, /sessions, /health, /uptime, /broadcast, /restart
"""

import asyncio
import logging
import os
import sys
import time
from pyrogram import Client, filters
from pyrogram.types import Message
from config.settings import is_owner, OWNER_ID, LOGGER_GROUP, SUDO_USERS

logger = logging.getLogger(__name__)


class OwnerCommands:
    def __init__(self, bot, assistant_manager, audio_bridge, db, health):
        self.bot = bot
        self.assistant_manager = assistant_manager
        self.audio_bridge = audio_bridge
        self.db = db
        self.health = health
        self.register_handlers()

    def register_handlers(self):

        @self.bot.on_message(filters.command("addsudo") & filters.private)
        async def addsudo_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            if len(message.command) < 2:
                return await message.reply("Usage: `/addsudo USER_ID`")

            try:
                user_id = int(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid user ID!")

            if user_id == OWNER_ID:
                return await message.reply("❌ That's the owner ID!")

            if user_id in SUDO_USERS:
                return await message.reply("⚠️ User is already a sudo user!")

            SUDO_USERS.append(user_id)
            self.db.add_sudo(user_id, message.from_user.id)
            self.health.increment_commands()

            await message.reply(f"✅ **Sudo user added:** `{user_id}`")

            # Log
            try:
                await client.send_message(
                    LOGGER_GROUP,
                    f"👑 **New Sudo User**\n\n"
                    f"User ID: `{user_id}`\n"
                    f"Added by: {message.from_user.mention}"
                )
            except:
                pass

        @self.bot.on_message(filters.command("delsudo") & filters.private)
        async def delsudo_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            if len(message.command) < 2:
                return await message.reply("Usage: `/delsudo USER_ID`")

            try:
                user_id = int(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid user ID!")

            if user_id == OWNER_ID:
                return await message.reply("❌ Cannot remove owner!")

            if user_id in SUDO_USERS:
                SUDO_USERS.remove(user_id)
            self.db.remove_sudo(user_id)
            self.health.increment_commands()

            await message.reply(f"✅ **Sudo user removed:** `{user_id}`")

        @self.bot.on_message(filters.command("listsudo") & filters.private)
        async def listsudo_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            self.health.increment_commands()

            text = f"**👑 Sudo Users**\n\n"
            text += f"👤 **Owner:** `{OWNER_ID}`\n\n"

            db_sudos = self.db.get_sudo_users()
            if db_sudos:
                for uid in db_sudos:
                    try:
                        user = await client.get_users(uid)
                        text += f"• `{uid}` - {user.mention}\n"
                    except:
                        text += f"• `{uid}`\n"
            elif SUDO_USERS:
                for uid in SUDO_USERS:
                    if uid != OWNER_ID:
                        text += f"• `{uid}`\n"
            else:
                text += "No additional sudo users.\n"

            await message.reply(text)

        @self.bot.on_message(filters.command("sessions") & filters.private)
        async def sessions_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            self.health.increment_commands()
            assistants = self.assistant_manager.get_all_assistants()

            if not assistants:
                return await message.reply("❌ **No active sessions!**\n\nUse `/addsession` to add one.")

            text = f"**📋 Active Sessions ({len(assistants)})**\n\n"
            for i, ass in enumerate(assistants, 1):
                active_chats = len(ass.get('active_chats', []))
                text += (
                    f"{i}. **{ass['name']}**\n"
                    f"   Username: @{ass.get('username', 'N/A')}\n"
                    f"   User ID: `{ass['user_id']}`\n"
                    f"   Active VCs: `{active_chats}`\n\n"
                )

            await message.reply(text)

        @self.bot.on_message(filters.command("health"))
        async def health_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            self.health.increment_commands()
            report = self.health.get_health_report()

            text = f"**🏥 Bot Health Report**\n\n"
            text += f"**System:**\n"
            text += f"• Uptime: `{report['uptime']}`\n"
            text += f"• Started: `{report['start_time']}`\n"
            text += f"• Memory: `{report['memory_mb']} MB`\n"
            text += f"• CPU: `{report['cpu_percent']}%`\n"
            text += f"• Threads: `{report['threads']}`\n"
            text += f"• Disk Free: `{report['disk_free_gb']} GB`\n\n"
            text += f"**Stats:**\n"
            text += f"• Commands Processed: `{report['commands_processed']}`\n"
            text += f"• Bridges Started: `{report['bridges_started']}`\n"
            text += f"• Errors: `{report['errors_count']}`\n\n"

            # Assistant status
            assistants = self.assistant_manager.get_all_assistants()
            text += f"**Assistants:** `{len(assistants)}`\n"

            # Bridge status
            bridge_status = self.audio_bridge.get_status()
            text += f"**Active Bridges:** `{bridge_status['active_bridges']}`\n"

            await message.reply(text)

        @self.bot.on_message(filters.command("uptime"))
        async def uptime_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            self.health.increment_commands()
            uptime = self.health.get_uptime()
            uptime_seconds = self.health.get_uptime_seconds()

            await message.reply(
                f"**⏱ Bot Uptime**\n\n"
                f"**Duration:** `{uptime}`\n"
                f"**Seconds:** `{int(uptime_seconds)}`\n"
                f"**Started:** `{self.health.start_datetime.strftime('%Y-%m-%d %H:%M:%S')}`"
            )

        @self.bot.on_message(filters.command("broadcast") & filters.private)
        async def broadcast_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            if len(message.command) < 2:
                return await message.reply("Usage: `/broadcast MESSAGE`")

            broadcast_text = message.text.split(None, 1)[1]
            status_msg = await message.reply("📢 **Broadcasting...**")
            self.health.increment_commands()

            count = 0
            assistants = self.assistant_manager.get_all_assistants()
            for ass in assistants:
                try:
                    await ass['client'].send_message(
                        "me",
                        f"📢 **VCFight V3 Broadcast**\n\n{broadcast_text}"
                    )
                    count += 1
                except:
                    pass

            await status_msg.edit(f"✅ **Broadcast sent to {count} assistant(s)!**")

        @self.bot.on_message(filters.command("restart") & filters.private)
        async def restart_cmd(client, message: Message):
            if not is_owner(message.from_user.id):
                return await message.reply("❌ **Owner only command!**")

            self.health.increment_commands()
            await message.reply("🔄 **Restarting bot...**")

            # Cleanup
            assistant = self.assistant_manager.get_primary()
            if assistant:
                await self.audio_bridge.stop_all_bridges(assistant['bridge'])

            # Log restart
            try:
                await client.send_message(
                    LOGGER_GROUP,
                    f"🔄 **Bot Restart**\n\nInitiated by: {message.from_user.mention}"
                )
            except:
                pass

            # Restart process
            os.execv(sys.executable, [sys.executable] + sys.argv)
