"""
VCFight V3 - VC Control Commands
/join, /record, /level, /mute, /unmute, /leaverecord, /leaveplay, /bass
"""

import asyncio
import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from config.settings import is_sudo, RECORD_GROUP, LOGGER_GROUP
from core.audio_processor import NuclearAudioProcessor

logger = logging.getLogger(__name__)


class VCCommands:
    def __init__(self, bot, assistant_manager, audio_bridge, db, health):
        self.bot = bot
        self.assistant_manager = assistant_manager
        self.audio_bridge = audio_bridge
        self.db = db
        self.health = health
        self.record_group = RECORD_GROUP
        self.play_chat_id = None  # The chat where /join was used
        self.register_handlers()

    def register_handlers(self):

        @self.bot.on_message(filters.command("join") & filters.group)
        async def join_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            assistant = self.assistant_manager.get_primary()
            if not assistant:
                return await message.reply(
                    "❌ **No assistant session!**\n\n"
                    "Use `/addsession` in PM to add an assistant account first."
                )

            chat_id = message.chat.id
            status_msg = await message.reply("🎙 **Joining voice chat...**")

            try:
                # Check if assistant is in the group
                if not await self.assistant_manager.check_membership(assistant['user_id'], chat_id):
                    await status_msg.edit(
                        f"❌ **Assistant not in this group!**\n\n"
                        f"Add @{assistant.get('username', 'assistant')} to this group first."
                    )
                    return

                # Start VC if not already active
                try:
                    peer = await assistant['client'].resolve_peer(chat_id)
                    from pyrogram.raw.functions.phone import CreateGroupCall
                    await assistant['client'].invoke(
                        CreateGroupCall(
                            peer=peer,
                            random_id=int(asyncio.get_event_loop().time() * 1000) % 1000000
                        )
                    )
                    await asyncio.sleep(2)
                except Exception:
                    pass  # VC may already exist

                # Join the VC
                result = await self.assistant_manager.join_vc(
                    assistant['user_id'], chat_id
                )

                if result:
                    self.play_chat_id = chat_id
                    self.health.increment_commands()

                    status = self.audio_bridge.get_status()
                    await status_msg.edit(
                        f"✅ **Joined Voice Chat!**\n\n"
                        f"**Chat:** `{chat_id}`\n"
                        f"**Assistant:** {assistant['name']}\n"
                        f"**Current Level:** `{status['level']}` ({status['volume_multiplier']}x)\n"
                        f"**Current Bass:** `{status['bass']}` ({status['bass_db']:.1f}dB)\n\n"
                        f"💡 Now use `/record` to start audio bridge from record group.\n"
                        f"💡 Use `/level 1-25` to set volume level.\n"
                        f"💡 Use `/bass 0-100` to set bass boost."
                    )
                else:
                    await status_msg.edit("❌ **Failed to join VC!** Make sure a voice chat is active.")

            except Exception as e:
                await status_msg.edit(f"❌ **Error:** `{str(e)[:200]}`")
                logger.error(f"join error: {e}")

        @self.bot.on_message(filters.command("record") & filters.group)
        async def record_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            assistant = self.assistant_manager.get_primary()
            if not assistant:
                return await message.reply("❌ **No assistant session!**")

            chat_id = message.chat.id
            status_msg = await message.reply("🎙 **Starting audio bridge...**")

            try:
                # Check if assistant is in record group
                if not await self.assistant_manager.check_membership(
                    assistant['user_id'], self.record_group
                ):
                    await status_msg.edit(
                        f"❌ **Assistant not in record group!**\n\n"
                        f"Add @{assistant.get('username', 'assistant')} to the record group "
                        f"(`{self.record_group}`) first."
                    )
                    return

                # Check if assistant is in this group (playback)
                if not await self.assistant_manager.check_membership(assistant['user_id'], chat_id):
                    await status_msg.edit(
                        f"❌ **Assistant not in this group!**\n\n"
                        f"Add @{assistant.get('username', 'assistant')} to this group first."
                    )
                    return

                # Start VC in record group if not active
                try:
                    peer = await assistant['client'].resolve_peer(self.record_group)
                    from pyrogram.raw.functions.phone import CreateGroupCall
                    await assistant['client'].invoke(
                        CreateGroupCall(
                            peer=peer,
                            random_id=int(asyncio.get_event_loop().time() * 1000) % 1000000
                        )
                    )
                    await asyncio.sleep(2)
                except Exception:
                    pass

                # Join record group VC (to listen)
                await self.assistant_manager.join_vc(
                    assistant['user_id'], self.record_group
                )

                # Start the audio bridge from record group to this chat
                result = await self.audio_bridge.start_bridge(
                    assistant['bridge'],
                    self.record_group,
                    chat_id
                )

                if result:
                    self.play_chat_id = chat_id
                    self.health.increment_commands()
                    self.health.increment_bridges()

                    status = self.audio_bridge.get_status()
                    self.db.log_bridge_start(
                        self.record_group, chat_id,
                        status['level'], status['bass'], status['voice_mode']
                    )

                    # Visual level bars
                    level_bar = "█" * status['level'] + "░" * (25 - status['level'])
                    bass_bar = "█" * int(status['bass'] / 5) + "░" * (20 - int(status['bass'] / 5))

                    await status_msg.edit(
                        f"🔥 **AUDIO BRIDGE ACTIVE!** 🔥\n\n"
                        f"**RECORD:** `{self.record_group}`\n"
                        f"**PLAYBACK:** `{chat_id}`\n\n"
                        f"**Level:** `{status['level']}/25` ({status['volume_multiplier']}x)\n"
                        f"`{level_bar}`\n\n"
                        f"**Bass:** `{status['bass']}/100` ({status['bass_db']:.1f}dB)\n"
                        f"`{bass_bar}`\n\n"
                        f"**Voice Mode:** `{status['voice_mode'].upper()}`\n"
                        f"**Echo:** `{status['echo']}%`\n\n"
                        f"💡 Speak in record group VC - it plays here with effects!\n"
                        f"💡 `/level 1-25` | `/bass 0-100` | `/robot` | `/shout`"
                    )

                    # Log to logger group
                    try:
                        await client.send_message(
                            LOGGER_GROUP,
                            f"🔥 **Bridge Started**\n\n"
                            f"Record: `{self.record_group}`\n"
                            f"Playback: `{chat_id}`\n"
                            f"Level: {status['level']} | Bass: {status['bass']}\n"
                            f"By: {message.from_user.mention}"
                        )
                    except:
                        pass
                else:
                    await status_msg.edit("❌ **Failed to start bridge!**")

            except Exception as e:
                await status_msg.edit(f"❌ **Error:** `{str(e)[:200]}`")
                logger.error(f"record error: {e}")

        @self.bot.on_message(filters.command("level") & filters.group)
        async def level_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if len(message.command) < 2:
                status = self.audio_bridge.get_status()
                level_bar = "█" * status['level'] + "░" * (25 - status['level'])
                return await message.reply(
                    f"**🔊 Current Level:** `{status['level']}/25` ({status['volume_multiplier']}x)\n"
                    f"`{level_bar}`\n\n"
                    f"Usage: `/level 1-25`\n\n"
                    f"**Level Guide:**\n"
                    f"• 1-5 = Normal volume\n"
                    f"• 6-10 = Loud (default: 10)\n"
                    f"• 11-15 = Very loud\n"
                    f"• 16-20 = Extremely loud\n"
                    f"• 21-25 = ☢️ NUCLEAR - Risk of speaker damage!"
                )

            try:
                level = int(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid level! Enter a number 1-25.")

            if not self.audio_bridge.set_level(level):
                return await message.reply("❌ Level must be between 1 and 25!")

            self.health.increment_commands()
            status = self.audio_bridge.get_status()
            level_bar = "█" * level + "░" * (25 - level)

            # Restart bridge with new level if active
            assistant = self.assistant_manager.get_primary()
            if assistant and self.audio_bridge.active_bridges:
                for chat_id in list(self.audio_bridge.active_bridges.keys()):
                    await self.audio_bridge.restart_bridge_with_effects(
                        assistant['bridge'], chat_id
                    )

            warning = ""
            if level >= 20:
                warning = "\n\n⚠️ **WARNING: EXTREME VOLUME!** May damage speakers/headphones!"
            elif level >= 15:
                warning = "\n\n⚠️ **Very high volume!** Proceed with caution."

            await message.reply(
                f"✅ **Level set to {level}/25** ({status['volume_multiplier']}x)\n"
                f"`{level_bar}`{warning}"
            )

        @self.bot.on_message(filters.command("bass") & filters.group)
        async def bass_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if len(message.command) < 2:
                status = self.audio_bridge.get_status()
                bass_bar = "█" * int(status['bass'] / 5) + "░" * (20 - int(status['bass'] / 5))
                return await message.reply(
                    f"**🎵 Bass Boost**\n\n"
                    f"Current: `{status['bass']}/100` ({status['bass_db']:.1f}dB)\n"
                    f"`{bass_bar}`\n\n"
                    f"Usage: `/bass 0-100`\n\n"
                    f"**Effect Levels:**\n"
                    f"• 0 = No boost\n"
                    f"• 20 = Mild bass\n"
                    f"• 50 = **DEVASTATING BASS** (default)\n"
                    f"• 80 = Earthquake\n"
                    f"• 100 = ☢️ Bass apocalypse - structural damage!"
                )

            try:
                bass = float(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid value!")

            if not self.audio_bridge.set_bass(bass):
                return await message.reply("❌ Bass must be between 0 and 100!")

            self.health.increment_commands()
            status = self.audio_bridge.get_status()
            bass_bar = "█" * int(bass / 5) + "░" * (20 - int(bass / 5))

            # Restart bridge with new bass if active
            assistant = self.assistant_manager.get_primary()
            if assistant and self.audio_bridge.active_bridges:
                for chat_id in list(self.audio_bridge.active_bridges.keys()):
                    await self.audio_bridge.restart_bridge_with_effects(
                        assistant['bridge'], chat_id
                    )

            await message.reply(
                f"✅ **Bass set to {bass}/100** ({status['bass_db']:.1f}dB)\n"
                f"`{bass_bar}`"
            )

        @self.bot.on_message(filters.command("mute") & filters.group)
        async def mute_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            chat_id = message.chat.id
            assistant = self.assistant_manager.get_primary()
            if not assistant:
                return await message.reply("❌ No assistant!")

            result = await self.assistant_manager.mute_vc(assistant['user_id'], chat_id)
            if result:
                self.audio_bridge.is_muted = True
                self.health.increment_commands()
                await message.reply("🔇 **Playback VC muted!** Use `/unmute` to unmute.")
            else:
                await message.reply("❌ Failed to mute. Make sure assistant is in VC.")

        @self.bot.on_message(filters.command("unmute") & filters.group)
        async def unmute_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            chat_id = message.chat.id
            assistant = self.assistant_manager.get_primary()
            if not assistant:
                return await message.reply("❌ No assistant!")

            result = await self.assistant_manager.unmute_vc(assistant['user_id'], chat_id)
            if result:
                self.audio_bridge.is_muted = False
                self.health.increment_commands()
                await message.reply("🔊 **Playback VC unmuted!** Audio is live!")
            else:
                await message.reply("❌ Failed to unmute.")

        @self.bot.on_message(filters.command("leaverecord") & filters.group)
        async def leaverecord_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            assistant = self.assistant_manager.get_primary()
            if not assistant:
                return await message.reply("❌ No assistant!")

            result = await self.assistant_manager.leave_vc(
                assistant['user_id'], self.record_group
            )
            if result:
                self.health.increment_commands()
                await message.reply("✅ **Left record VC!**")
            else:
                await message.reply("❌ Failed to leave record VC.")

        @self.bot.on_message(filters.command("leaveplay") & filters.group)
        async def leaveplay_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            chat_id = message.chat.id
            assistant = self.assistant_manager.get_primary()
            if not assistant:
                return await message.reply("❌ No assistant!")

            # Stop bridge if active
            if chat_id in self.audio_bridge.active_bridges:
                await self.audio_bridge.stop_bridge(assistant['bridge'], chat_id)
                self.db.log_bridge_end(chat_id)

            result = await self.assistant_manager.leave_vc(assistant['user_id'], chat_id)
            if result:
                self.play_chat_id = None
                self.health.increment_commands()
                await message.reply("✅ **Left playback VC and stopped bridge!**")
            else:
                await message.reply("❌ Failed to leave playback VC.")
