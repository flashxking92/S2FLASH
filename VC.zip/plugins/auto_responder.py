"""
VCFight V3 - Auto Responder Commands
/addresponse, /listresponses, /delresponse, /smartmute, /voicestats
"""

import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from config.settings import is_sudo

logger = logging.getLogger(__name__)


class AutoResponderCommands:
    def __init__(self, bot, auto_responder, db, health):
        self.bot = bot
        self.auto_responder = auto_responder
        self.db = db
        self.health = health
        self.register_handlers()

    def register_handlers(self):

        @self.bot.on_message(filters.command("addresponse") & filters.group)
        async def addresponse_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            # Format: /addresponse trigger | response
            if len(message.command) < 2:
                return await message.reply(
                    "**🤖 Add Auto-Response**\n\n"
                    "Usage: `/addresponse trigger | response`\n\n"
                    "**Examples:**\n"
                    "`/addresponse hello | Hey there! 👋`\n"
                    "`/addresponse hi | Hello! How are you?`\n\n"
                    "The bot will automatically respond when it sees the trigger word/phrase."
                )

            text = message.text.split(None, 1)[1]
            if "|" not in text:
                return await message.reply("❌ Use format: `/addresponse trigger | response`")

            parts = text.split("|", 1)
            trigger = parts[0].strip()
            response = parts[1].strip()

            if not trigger or not response:
                return await message.reply("❌ Both trigger and response are required!")

            is_voice = response.startswith("voice:")

            if self.db.add_response(trigger, response, is_voice, message.from_user.id):
                self.health.increment_commands()
                await message.reply(
                    f"✅ **Auto-response added!**\n\n"
                    f"**Trigger:** `{trigger}`\n"
                    f"**Response:** `{response}`\n"
                    f"**Type:** {'Voice' if is_voice else 'Text'}"
                )
            else:
                await message.reply("❌ Failed to add auto-response!")

        @self.bot.on_message(filters.command("listresponses"))
        async def listresponses_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            responses = self.db.get_responses()
            self.health.increment_commands()

            if not responses:
                return await message.reply("❌ **No auto-responses configured!**\n\nUse `/addresponse trigger | response` to add one.")

            text = f"**🤖 Auto-Responses ({len(responses)})**\n\n"
            for r in responses:
                rtype = "🎤" if r.is_voice else "💬"
                text += (
                    f"{rtype} **#{r.id}** | Trigger: `{r.trigger}`\n"
                    f"   Response: `{r.response[:50]}`\n\n"
                )
            text += "Use `/delresponse ID` to delete."

            await message.reply(text)

        @self.bot.on_message(filters.command("delresponse") & filters.group)
        async def delresponse_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if len(message.command) < 2:
                return await message.reply("Usage: `/delresponse ID`")

            try:
                resp_id = int(message.command[1])
            except ValueError:
                return await message.reply("❌ Invalid ID!")

            if self.db.remove_response(resp_id):
                self.health.increment_commands()
                await message.reply(f"✅ **Auto-response #{resp_id} deleted!**")
            else:
                await message.reply(f"❌ Auto-response #{resp_id} not found!")

        @self.bot.on_message(filters.command("smartmute") & filters.group)
        async def smartmute_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            chat_id = message.chat.id
            enabled = self.auto_responder.toggle_smart_mute(chat_id)
            self.health.increment_commands()
            self.audio_bridge.smart_mute_enabled = enabled

            status = "✅ ENABLED" if enabled else "❌ DISABLED"
            await message.reply(
                f"**🧠 Smart Mute: {status}**\n\n"
                f"When enabled, the bot will intelligently mute/unmute\n"
                f"the playback stream based on voice activity in the record VC."
            )

        @self.bot.on_message(filters.command("voicestats"))
        async def voicestats_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            self.health.increment_commands()

            # Get voice stats from database
            chat_id = message.chat.id
            stats = self.db.get_voice_stats(chat_id)

            # Get auto-responder stats
            ar_stats = self.auto_responder.get_stats()

            # Get bridge status
            bridge_status = self.audio_bridge.get_status()

            text = f"**📊 Voice Statistics**\n\n"
            text += f"**Bridge Status:**\n"
            text += f"• Active Bridges: `{bridge_status['active_bridges']}`\n"
            text += f"• Current Level: `{bridge_status['level']}/25`\n"
            text += f"• Current Bass: `{bridge_status['bass']}/100`\n"
            text += f"• Voice Mode: `{bridge_status['voice_mode'].upper()}`\n\n"

            if stats:
                for s in stats:
                    if s:
                        text += f"**Chat `{s.chat_id}` Stats:**\n"
                        text += f"• Total Duration: `{s.total_duration:.1f}s`\n"
                        text += f"• Peak Level: `{s.peak_level}/25`\n"
                        text += f"• Bridges Started: `{s.bridges_started}`\n"
                        text += f"• Last Active: `{s.last_active}`\n\n"

            text += f"**Auto-Responder:**\n"
            text += f"• Total Responses: `{ar_stats['total_responses']}`\n"
            text += f"• Smart Mute Chats: `{ar_stats['smart_mute_chats']}`\n"

            await message.reply(text)
