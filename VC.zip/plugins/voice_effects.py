"""
VCFight V3 - Voice Effects Commands
/robot, /echo, /whisper, /shout, /resetvoice, /preset
"""

import asyncio
import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from config.settings import is_sudo
from core.audio_processor import NuclearAudioProcessor

logger = logging.getLogger(__name__)


class VoiceEffectsCommands:
    def __init__(self, bot, assistant_manager, audio_bridge, db, health):
        self.bot = bot
        self.assistant_manager = assistant_manager
        self.audio_bridge = audio_bridge
        self.db = db
        self.health = health
        self.register_handlers()

    def register_handlers(self):

        @self.bot.on_message(filters.command("robot") & filters.group)
        async def robot_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if not self.audio_bridge.set_voice_mode("robot"):
                return await message.reply("❌ Failed to set robot mode!")

            self.health.increment_commands()
            await self._apply_effects(message)

            await message.reply(
                "🤖 **ROBOT MODE ACTIVATED!**\n\n"
                "Your voice will sound metallic and robotic.\n"
                "Like a terminator speaking through a megaphone.\n\n"
                "💡 Use `/resetvoice` to return to normal."
            )

        @self.bot.on_message(filters.command("echo") & filters.group)
        async def echo_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            echo_value = 60  # Default echo intensity
            if len(message.command) >= 2:
                try:
                    echo_value = float(message.command[1])
                    if not (0 <= echo_value <= 100):
                        return await message.reply("❌ Echo must be 0-100!")
                except ValueError:
                    return await message.reply("❌ Invalid value!")

            self.audio_bridge.set_voice_mode("echo")
            self.audio_bridge.set_echo(echo_value)
            self.health.increment_commands()
            await self._apply_effects(message)

            echo_bar = "█" * int(echo_value / 5) + "░" * (20 - int(echo_value / 5))
            await message.reply(
                f"📢 **ECHO MODE ACTIVATED!**\n\n"
                f"Echo Intensity: `{echo_value}%`\n"
                f"`{echo_bar}`\n\n"
                f"Your voice will echo through the VC like thunder.\n\n"
                f"💡 `/echo 0-100` to adjust | `/resetvoice` to disable."
            )

        @self.bot.on_message(filters.command("whisper") & filters.group)
        async def whisper_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if not self.audio_bridge.set_voice_mode("whisper"):
                return await message.reply("❌ Failed to set whisper mode!")

            self.health.increment_commands()
            await self._apply_effects(message)

            await message.reply(
                "👻 **WHISPER MODE ACTIVATED!**\n\n"
                "Your voice will sound haunting and intimate.\n"
                "Like a ghost whispering directly into everyone's ears.\n"
                "Still amplified - the whisper will cut through the VC.\n\n"
                "💡 Use `/resetvoice` to return to normal."
            )

        @self.bot.on_message(filters.command("shout") & filters.group)
        async def shout_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if not self.audio_bridge.set_voice_mode("shout"):
                return await message.reply("❌ Failed to set shout mode!")

            self.health.increment_commands()
            await self._apply_effects(message)

            await message.reply(
                "💥 **SHOUT MODE ACTIVATED!** 💥\n\n"
                "☢️ MAXIMUM AGGRESSION MODE ☢️\n\n"
                "Your voice will sound like screaming through a stadium megaphone.\n"
                "Every word will hit like a sledgehammer.\n"
                "Distortion + overdrive + heavy compression = DEVASTATION.\n\n"
                f"⚠️ **WARNING:** This is EXTREME. Use `/resetvoice` to disable."
            )

        @self.bot.on_message(filters.command("resetvoice") & filters.group)
        async def resetvoice_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            self.audio_bridge.reset_voice()
            self.health.increment_commands()
            await self._apply_effects(message)

            status = self.audio_bridge.get_status()
            await message.reply(
                f"✅ **Voice effects reset to default!**\n\n"
                f"**Level:** `{status['level']}/25`\n"
                f"**Bass:** `{status['bass']}/100`\n"
                f"**Voice Mode:** `{status['voice_mode'].upper()}`\n"
                f"**Echo:** `{status['echo']}%`"
            )

        @self.bot.on_message(filters.command("preset") & filters.group)
        async def preset_cmd(client, message: Message):
            if not is_sudo(message.from_user.id):
                return await message.reply("❌ **Unauthorized!**")

            if len(message.command) < 2:
                presets = NuclearAudioProcessor.__dict__.get('get_preset', lambda x: None)
                return await message.reply(
                    "**🎭 Available Presets**\n\n"
                    "☢️ `/preset nuclear` - MAXIMUM DESTRUCTION\n"
                    "🌍 `/preset earthquake` - Bass annihilation\n"
                    "👹 `/preset demon` - Demonic robot voice\n"
                    "👻 `/preset ghost` - Haunting whisper\n"
                    "🏟 `/preset stadium` - Stadium echo effect\n"
                    "🔧 `/preset normal` - Default devastating mode\n"
                    "✨ `/preset clean` - Clean boosted audio"
                )

            preset_name = message.command[1].lower()
            preset = NuclearAudioProcessor.get_preset(preset_name)

            if not preset:
                return await message.reply(f"❌ Preset '{preset_name}' not found!")

            # Apply preset
            self.audio_bridge.set_level(preset['level'])
            self.audio_bridge.set_bass(preset['bass'])
            self.audio_bridge.set_voice_mode(preset['voice_mode'])
            self.audio_bridge.set_echo(preset.get('echo', 0))
            self.health.increment_commands()

            await self._apply_effects(message)

            level_bar = "█" * preset['level'] + "░" * (25 - preset['level'])
            bass_bar = "█" * int(preset['bass'] / 5) + "░" * (20 - int(preset['bass'] / 5))

            await message.reply(
                f"✅ **Preset '{preset_name.upper()}' Applied!**\n\n"
                f"**{preset['description']}**\n\n"
                f"Level: `{preset['level']}/25`\n`{level_bar}`\n\n"
                f"Bass: `{preset['bass']}/100`\n`{bass_bar}`\n\n"
                f"Voice: `{preset['voice_mode'].upper()}`\n"
                f"Echo: `{preset.get('echo', 0)}%`"
            )

        @self.bot.on_message(filters.command("effects") & filters.group)
        async def effects_cmd(client, message: Message):
            """Show current effects dashboard."""
            status = self.audio_bridge.get_status()

            level_bar = "█" * status['level'] + "░" * (25 - status['level'])
            bass_bar = "█" * int(status['bass'] / 5) + "░" * (20 - int(status['bass'] / 5))
            echo_bar = "█" * int(status['echo'] / 5) + "░" * (20 - int(status['echo'] / 5))

            mode_emoji = {
                'normal': '🔧', 'robot': '🤖', 'echo': '📢',
                'whisper': '👻', 'shout': '💥'
            }
            mode_icon = mode_emoji.get(status['voice_mode'], '🔧')

            await message.reply(
                f"**🎛 Effects Dashboard**\n\n"
                f"┌──────────────────────────────┐\n"
                f"│ **LEVEL**  | `{level_bar}` | `{status['level']}/25` ({status['volume_multiplier']}x)\n"
                f"│ **BASS**   | `{bass_bar}` | `{status['bass']}/100` ({status['bass_db']:.1f}dB)\n"
                f"│ **ECHO**   | `{echo_bar}` | `{status['echo']}%`\n"
                f"│ **MODE**   | {mode_icon} `{status['voice_mode'].upper()}`\n"
                f"│ **MUTED**  | `{'YES 🔇' if status['muted'] else 'NO 🔊'}`\n"
                f"│ **BRIDGES**| `{status['active_bridges']}`\n"
                f"└──────────────────────────────┘\n\n"
                f"**Commands:**\n"
                f"• `/level 1-25` - Set volume level\n"
                f"• `/bass 0-100` - Set bass boost\n"
                f"• `/echo 0-100` - Set echo\n"
                f"• `/robot` `/whisper` `/shout` - Voice modes\n"
                f"• `/preset NAME` - Apply preset\n"
                f"• `/resetvoice` - Reset to default"
            )

    async def _apply_effects(self, message: Message):
        """Restart bridges with current effects."""
        assistant = self.assistant_manager.get_primary()
        if assistant and self.audio_bridge.active_bridges:
            for chat_id in list(self.audio_bridge.active_bridges.keys()):
                try:
                    await self.audio_bridge.restart_bridge_with_effects(
                        assistant['bridge'], chat_id
                    )
                except Exception as e:
                    logger.error(f"Failed to restart bridge with effects: {e}")
