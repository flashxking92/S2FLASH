#!/usr/bin/env python3
"""
VCFight V3 - Session String Generator
Generate Pyrogram session string for the assistant account.
"""

import asyncio
from pyrogram import Client


async def main():
    print("\n" + "🔑" * 25)
    print("🔑 VCFight V3 - Session String Generator")
    print("🔑" * 25)

    api_id = int(input("\n📱 Enter your API ID: "))
    api_hash = input("🔑 Enter your API HASH: ")

    print("\n📋 You will now be asked to login with your phone number.")
    print("⚠️ Make sure you have a Telegram account for the ASSISTANT bot.")
    print("⚠️ This should be a DIFFERENT account from your main account.\n")

    app = Client("session_gen", api_id=api_id, api_hash=api_hash)

    try:
        await app.start()
        me = await app.get_me()
        session_string = await app.export_session_string()

        print("\n" + "✅" * 25)
        print("✅ SESSION STRING GENERATED!")
        print("✅" * 25)
        print(f"\n📋 COPY THIS STRING (Keep it safe!):\n")
        print(session_string)
        print(f"\n{'✅' * 25}")
        print(f"👤 Account: {me.first_name} (@{me.username})")
        print(f"🆔 User ID: {me.id}")
        print(f"{'✅' * 25}")
        print("\n⚠️ Never share this session string with anyone!")
        print("Use /addsession in bot PM to add this assistant.\n")

    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        await app.stop()


if __name__ == "__main__":
    asyncio.run(main())
