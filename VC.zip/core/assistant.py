"""
VCFight V3 - Assistant Manager
Manages assistant (userbot) sessions for joining voice chats.
"""

import asyncio
import logging
import time
from typing import Dict, Optional, List
from pyrogram import Client
from pyrogram.errors import UserNotParticipant, SessionRevoked, FloodWait
from pytgcalls import PyTgCalls
from pytgcalls.types import AudioPiped, AudioQuality

logger = logging.getLogger(__name__)


class AssistantManager:
    def __init__(self, api_id: int, api_hash: str):
        self.api_id = api_id
        self.api_hash = api_hash
        self.assistants: Dict[int, dict] = {}  # user_id -> assistant data
        self.primary_assistant_id: Optional[int] = None

    async def add_assistant(self, session_string: str, name: str = None) -> Optional[dict]:
        """Add a new assistant using session string."""
        try:
            client = Client(
                name or f"assistant_{int(time.time())}",
                api_id=self.api_id,
                api_hash=self.api_hash,
                session_string=session_string,
                in_memory=True
            )
            await client.start()
            me = await client.get_me()

            bridge = PyTgCalls(client)
            await bridge.start()

            assistant_data = {
                'client': client,
                'bridge': bridge,
                'user_id': me.id,
                'name': me.first_name,
                'username': me.username,
                'session_string': session_string,
                'added_at': time.time(),
                'active_chats': set(),
            }

            self.assistants[me.id] = assistant_data
            if self.primary_assistant_id is None:
                self.primary_assistant_id = me.id

            logger.info(f"✅ Assistant added: {me.first_name} (@{me.username}) ID:{me.id}")
            return assistant_data

        except SessionRevoked:
            logger.error("❌ Session string invalid or revoked")
            return None
        except Exception as e:
            logger.error(f"❌ Failed to add assistant: {e}")
            return None

    async def remove_assistant(self, user_id: int) -> bool:
        """Remove an assistant by user_id."""
        if user_id in self.assistants:
            try:
                # Leave all active VCs first
                assistant = self.assistants[user_id]
                for chat_id in list(assistant.get('active_chats', [])):
                    try:
                        await assistant['bridge'].leave_group_call(chat_id)
                    except:
                        pass
                await assistant['client'].stop()
            except:
                pass
            del self.assistants[user_id]
            if self.primary_assistant_id == user_id:
                self.primary_assistant_id = (
                    list(self.assistants.keys())[0] if self.assistants else None
                )
            logger.info(f"✅ Assistant removed: {user_id}")
            return True
        return False

    def get_primary(self) -> Optional[dict]:
        """Get the primary assistant."""
        if self.primary_assistant_id and self.primary_assistant_id in self.assistants:
            return self.assistants[self.primary_assistant_id]
        if self.assistants:
            return list(self.assistants.values())[0]
        return None

    def get_assistant(self, user_id: int) -> Optional[dict]:
        """Get assistant by user_id."""
        return self.assistants.get(user_id)

    def get_all_assistants(self) -> List[dict]:
        """Get all assistants."""
        return list(self.assistants.values())

    def get_assistant_count(self) -> int:
        """Get number of assistants."""
        return len(self.assistants)

    async def join_vc(self, user_id: int, chat_id: int, audio_path: str = None) -> bool:
        """Make an assistant join a voice chat with optional audio stream."""
        assistant = self.assistants.get(user_id)
        if not assistant:
            return False
        try:
            if audio_path:
                await assistant['bridge'].join_group_call(
                    chat_id,
                    AudioPiped(audio_path, AudioQuality.HIGH)
                )
            else:
                await assistant['bridge'].join_group_call(
                    chat_id,
                    AudioPiped(audio_path or "https://raw.githubusercontent.com/ninjatech/test/main/silence.raw", AudioQuality.HIGH)
                )
            assistant['active_chats'].add(chat_id)
            logger.info(f"✅ Assistant {user_id} joined VC in {chat_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to join VC: {e}")
            return False

    async def leave_vc(self, user_id: int, chat_id: int) -> bool:
        """Make an assistant leave a voice chat."""
        assistant = self.assistants.get(user_id)
        if not assistant:
            return False
        try:
            await assistant['bridge'].leave_group_call(chat_id)
            assistant['active_chats'].discard(chat_id)
            logger.info(f"✅ Assistant {user_id} left VC in {chat_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to leave VC: {e}")
            return False

    async def mute_vc(self, user_id: int, chat_id: int) -> bool:
        """Mute an assistant in a voice chat."""
        assistant = self.assistants.get(user_id)
        if not assistant:
            return False
        try:
            await assistant['bridge'].mute_stream(chat_id)
            logger.info(f"✅ Assistant {user_id} muted in {chat_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to mute: {e}")
            return False

    async def unmute_vc(self, user_id: int, chat_id: int) -> bool:
        """Unmute an assistant in a voice chat."""
        assistant = self.assistants.get(user_id)
        if not assistant:
            return False
        try:
            await assistant['bridge'].unmute_stream(chat_id)
            logger.info(f"✅ Assistant {user_id} unmuted in {chat_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to unmute: {e}")
            return False

    async def change_stream(self, user_id: int, chat_id: int, audio_path: str) -> bool:
        """Change the audio stream for an assistant in VC."""
        assistant = self.assistants.get(user_id)
        if not assistant:
            return False
        try:
            await assistant['bridge'].change_stream(
                chat_id,
                AudioPiped(audio_path, AudioQuality.HIGH)
            )
            logger.info(f"✅ Stream changed for assistant {user_id} in {chat_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to change stream: {e}")
            return False

    async def check_membership(self, user_id: int, chat_id: int) -> bool:
        """Check if assistant is member of a chat."""
        assistant = self.assistants.get(user_id)
        if not assistant:
            return False
        try:
            member = await assistant['client'].get_chat_member(chat_id, "me")
            return member is not None
        except UserNotParticipant:
            return False
        except Exception as e:
            logger.error(f"❌ Membership check error: {e}")
            return False
