"""
VCFight V3 - Database Manager
SQLite database for persistent storage of sessions, responses, sudo users, etc.
"""

import json
import os
import logging
from datetime import datetime
from typing import List, Optional, Dict
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

logger = logging.getLogger(__name__)

Base = declarative_base()


class AssistantDB(Base):
    __tablename__ = 'assistants'
    id = Column(Integer, primary_key=True)
    session_string = Column(Text, unique=True)
    name = Column(String)
    user_id = Column(Integer, unique=True)
    username = Column(String)
    added_at = Column(DateTime, default=datetime.now)


class SudoUserDB(Base):
    __tablename__ = 'sudo_users'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, unique=True)
    added_by = Column(Integer)
    added_at = Column(DateTime, default=datetime.now)


class AutoResponseDB(Base):
    __tablename__ = 'auto_responses'
    id = Column(Integer, primary_key=True)
    trigger = Column(Text)
    response = Column(Text)
    is_voice = Column(Boolean, default=False)
    added_by = Column(Integer)
    added_at = Column(DateTime, default=datetime.now)


class BridgeLogDB(Base):
    __tablename__ = 'bridge_logs'
    id = Column(Integer, primary_key=True)
    record_chat_id = Column(Integer)
    play_chat_id = Column(Integer)
    level = Column(Integer)
    bass = Column(Float)
    voice_mode = Column(String)
    started_at = Column(DateTime, default=datetime.now)
    ended_at = Column(DateTime, nullable=True)


class VoiceStatsDB(Base):
    __tablename__ = 'voice_stats'
    id = Column(Integer, primary_key=True)
    chat_id = Column(Integer)
    total_duration = Column(Float, default=0.0)
    peak_level = Column(Integer, default=0)
    bridges_started = Column(Integer, default=0)
    last_active = Column(DateTime, default=datetime.now)


class DatabaseManager:
    def __init__(self, db_path: str = "sqlite:///vcfight_v3.db"):
        self.engine = create_engine(db_path, connect_args={'check_same_thread': False})
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)
        logger.info("✅ Database initialized")

    def _get_session(self):
        return self.Session()

    # ==================== ASSISTANT OPERATIONS ====================

    def save_assistant(self, session_string: str, name: str, user_id: int, username: str = None):
        session = self._get_session()
        try:
            existing = session.query(AssistantDB).filter_by(user_id=user_id).first()
            if not existing:
                assistant = AssistantDB(
                    session_string=session_string, name=name,
                    user_id=user_id, username=username
                )
                session.add(assistant)
                session.commit()
                logger.info(f"💾 Assistant saved: {name}")
        except Exception as e:
            logger.error(f"❌ Save assistant error: {e}")
            session.rollback()
        finally:
            session.close()

    def get_assistants(self) -> List[AssistantDB]:
        session = self._get_session()
        try:
            return session.query(AssistantDB).all()
        finally:
            session.close()

    def remove_assistant(self, user_id: int):
        session = self._get_session()
        try:
            session.query(AssistantDB).filter_by(user_id=user_id).delete()
            session.commit()
        except Exception as e:
            logger.error(f"❌ Remove assistant error: {e}")
            session.rollback()
        finally:
            session.close()

    # ==================== SUDO USER OPERATIONS ====================

    def add_sudo(self, user_id: int, added_by: int) -> bool:
        session = self._get_session()
        try:
            existing = session.query(SudoUserDB).filter_by(user_id=user_id).first()
            if not existing:
                sudo = SudoUserDB(user_id=user_id, added_by=added_by)
                session.add(sudo)
                session.commit()
                return True
            return False
        except Exception as e:
            logger.error(f"❌ Add sudo error: {e}")
            session.rollback()
            return False
        finally:
            session.close()

    def remove_sudo(self, user_id: int) -> bool:
        session = self._get_session()
        try:
            result = session.query(SudoUserDB).filter_by(user_id=user_id).delete()
            session.commit()
            return result > 0
        except Exception as e:
            logger.error(f"❌ Remove sudo error: {e}")
            session.rollback()
            return False
        finally:
            session.close()

    def get_sudo_users(self) -> List[int]:
        session = self._get_session()
        try:
            sudos = session.query(SudoUserDB).all()
            return [s.user_id for s in sudos]
        finally:
            session.close()

    def is_sudo(self, user_id: int) -> bool:
        session = self._get_session()
        try:
            return session.query(SudoUserDB).filter_by(user_id=user_id).first() is not None
        finally:
            session.close()

    # ==================== AUTO RESPONSE OPERATIONS ====================

    def add_response(self, trigger: str, response: str, is_voice: bool, added_by: int) -> bool:
        session = self._get_session()
        try:
            auto_resp = AutoResponseDB(
                trigger=trigger, response=response,
                is_voice=is_voice, added_by=added_by
            )
            session.add(auto_resp)
            session.commit()
            return True
        except Exception as e:
            logger.error(f"❌ Add response error: {e}")
            session.rollback()
            return False
        finally:
            session.close()

    def get_responses(self) -> List[AutoResponseDB]:
        session = self._get_session()
        try:
            return session.query(AutoResponseDB).all()
        finally:
            session.close()

    def remove_response(self, response_id: int) -> bool:
        session = self._get_session()
        try:
            result = session.query(AutoResponseDB).filter_by(id=response_id).delete()
            session.commit()
            return result > 0
        except Exception as e:
            logger.error(f"❌ Remove response error: {e}")
            session.rollback()
            return False
        finally:
            session.close()

    def find_response(self, text: str) -> Optional[str]:
        """Find an auto-response for the given text."""
        session = self._get_session()
        try:
            responses = session.query(AutoResponseDB).all()
            for r in responses:
                if r.trigger.lower() in text.lower():
                    return r.response
            return None
        finally:
            session.close()

    # ==================== BRIDGE LOG OPERATIONS ====================

    def log_bridge_start(self, record_chat_id: int, play_chat_id: int,
                         level: int, bass: float, voice_mode: str):
        session = self._get_session()
        try:
            log = BridgeLogDB(
                record_chat_id=record_chat_id, play_chat_id=play_chat_id,
                level=level, bass=bass, voice_mode=voice_mode
            )
            session.add(log)
            session.commit()
        except Exception as e:
            logger.error(f"❌ Log bridge error: {e}")
            session.rollback()
        finally:
            session.close()

    def log_bridge_end(self, play_chat_id: int):
        session = self._get_session()
        try:
            bridge = session.query(BridgeLogDB).filter_by(
                play_chat_id=play_chat_id, ended_at=None
            ).first()
            if bridge:
                bridge.ended_at = datetime.now()
                session.commit()
        except Exception as e:
            logger.error(f"❌ Log bridge end error: {e}")
            session.rollback()
        finally:
            session.close()

    # ==================== VOICE STATS OPERATIONS ====================

    def update_voice_stats(self, chat_id: int, duration: float = 0, level: int = 0, bridge_count: int = 0):
        session = self._get_session()
        try:
            stats = session.query(VoiceStatsDB).filter_by(chat_id=chat_id).first()
            if not stats:
                stats = VoiceStatsDB(chat_id=chat_id)
                session.add(stats)
            stats.total_duration += duration
            if level > stats.peak_level:
                stats.peak_level = level
            stats.bridges_started += bridge_count
            stats.last_active = datetime.now()
            session.commit()
        except Exception as e:
            logger.error(f"❌ Update stats error: {e}")
            session.rollback()
        finally:
            session.close()

    def get_voice_stats(self, chat_id: int = None) -> List[VoiceStatsDB]:
        session = self._get_session()
        try:
            if chat_id:
                return [session.query(VoiceStatsDB).filter_by(chat_id=chat_id).first()]
            return session.query(VoiceStatsDB).all()
        finally:
            session.close()

    # ==================== CONFIG OPERATIONS ====================

    def save_config(self, key: str, value):
        """Save a config value to a JSON file."""
        config_file = "vcfight_config.json"
        config = {}
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
        config[key] = value
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=4)

    def load_config(self, key: str, default=None):
        """Load a config value from JSON file."""
        import os
        config_file = "vcfight_config.json"
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
                return config.get(key, default)
        return default
