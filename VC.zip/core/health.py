"""
VCFight V3 - Bot Health Monitor
Tracks uptime, memory usage, and system health.
"""

import time
import os
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class HealthMonitor:
    """Monitor bot health, uptime, and system resources."""

    def __init__(self):
        self.start_time = time.time()
        self.start_datetime = datetime.now()
        self.commands_processed = 0
        self.errors_count = 0
        self.bridges_started = 0
        self.audio_processed_seconds = 0.0

    def get_uptime(self) -> str:
        """Get formatted uptime string."""
        uptime_seconds = int(time.time() - self.start_time)
        days = uptime_seconds // 86400
        hours = (uptime_seconds % 86400) // 3600
        minutes = (uptime_seconds % 3600) // 60
        seconds = uptime_seconds % 60

        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0:
            parts.append(f"{hours}h")
        if minutes > 0:
            parts.append(f"{minutes}m")
        parts.append(f"{seconds}s")
        return " ".join(parts)

    def get_uptime_seconds(self) -> float:
        return time.time() - self.start_time

    def get_health_report(self) -> dict:
        """Get comprehensive health report."""
        report = {
            'uptime': self.get_uptime(),
            'start_time': self.start_datetime.strftime("%Y-%m-%d %H:%M:%S"),
            'commands_processed': self.commands_processed,
            'errors_count': self.errors_count,
            'bridges_started': self.bridges_started,
            'audio_processed_seconds': self.audio_processed_seconds,
        }

        # System info
        try:
            import psutil
            process = psutil.Process(os.getpid())
            report['memory_mb'] = round(process.memory_info().rss / 1024 / 1024, 2)
            report['cpu_percent'] = round(process.cpu_percent(), 1)
            report['threads'] = process.num_threads()
        except ImportError:
            report['memory_mb'] = 'N/A (psutil not installed)'
            report['cpu_percent'] = 'N/A'
            report['threads'] = 'N/A'

        # Disk usage
        try:
            disk = os.statvfs('.')
            total_gb = round((disk.f_blocks * disk.f_frsize) / (1024**3), 2)
            free_gb = round((disk.f_bavail * disk.f_frsize) / (1024**3), 2)
            report['disk_total_gb'] = total_gb
            report['disk_free_gb'] = free_gb
        except:
            report['disk_total_gb'] = 'N/A'
            report['disk_free_gb'] = 'N/A'

        return report

    def increment_commands(self):
        self.commands_processed += 1

    def increment_errors(self):
        self.errors_count += 1

    def increment_bridges(self):
        self.bridges_started += 1
