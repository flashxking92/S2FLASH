"""
VCFight V3 - Nuclear Audio Processor
The most devastating FFmpeg filter chains ever built for Telegram VC.
When this hits, everyone in the VC will feel it.
"""

import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class NuclearAudioProcessor:
    """
    Builds absolutely devastating FFmpeg audio filter chains.
    The output is so intense it overwhelms every listener in the VC.
    """

    # Level mapping: /level 1-25 -> actual volume multiplier
    # Level 1 = 1.0x, Level 25 = 25.0x (absolutely nuclear)
    LEVEL_MAP = {
        1: 1.0, 2: 1.5, 3: 2.0, 4: 2.8, 5: 3.5,
        6: 4.5, 7: 5.5, 8: 6.5, 9: 7.5, 10: 9.0,
        11: 10.5, 12: 12.0, 13: 13.5, 14: 15.0, 15: 17.0,
        16: 19.0, 17: 21.0, 18: 23.0, 19: 25.0, 20: 27.5,
        21: 30.0, 22: 33.0, 23: 36.0, 24: 40.0, 25: 45.0,
    }

    @staticmethod
    def build_devastating_filter(
        level: int = 10,
        bass: float = 50,
        voice_mode: str = "normal",
        echo: float = 0,
        smart_mute: bool = False,
    ) -> str:
        """
        Build the most devastating FFmpeg audio filter chain.

        Args:
            level: Volume level 1-25 (maps to extreme multipliers)
            bass: Bass boost 0-100 (at 50 = absolutely nuclear bass)
            voice_mode: "normal", "robot", "echo", "whisper", "shout"
            echo: Echo intensity 0-100
            smart_mute: Enable intelligent mute control

        Returns:
            FFmpeg filter string that will tear apart the VC
        """
        filters = []

        # ========== PHASE 1: INPUT CONDITIONING ==========
        # Clean up the input signal first for maximum clarity
        filters.append("highpass=f=50")          # Remove sub-bass rumble below 50Hz
        filters.append("lowpass=f=18000")        # Remove useless ultra-high frequencies

        # ========== PHASE 2: VOICE MODE EFFECTS ==========
        if voice_mode == "robot":
            filters.extend(NuclearAudioProcessor._robot_filter())
        elif voice_mode == "whisper":
            filters.extend(NuclearAudioProcessor._whisper_filter())
        elif voice_mode == "shout":
            filters.extend(NuclearAudioProcessor._shout_filter())
        elif voice_mode == "echo":
            filters.extend(NuclearAudioProcessor._echo_filter(echo if echo > 0 else 60))

        # ========== PHASE 3: NUCLEAR BASS BOOST ==========
        filters.extend(NuclearAudioProcessor._bass_nuke(bass))

        # ========== PHASE 4: MULTI-STAGE COMPRESSION ==========
        # This is what makes the audio hit HARD - aggressive compression
        # so quiet parts are loud and loud parts are INSANELY loud
        filters.extend(NuclearAudioProcessor._compression_nuke(level))

        # ========== PHASE 5: LOUDNESS MAXIMIZATION ==========
        # EBU R128 loudness normalization - makes everything broadcast-loud
        filters.append("loudnorm=I=-6:TP=-0.5:LRA=4")

        # ========== PHASE 6: LEVEL-BASED VOLUME ==========
        # The actual volume multiplier based on /level command
        volume = NuclearAudioProcessor.LEVEL_MAP.get(level, 9.0)
        filters.append(f"volume={volume}")

        # ========== PHASE 7: FINAL POLISH ==========
        # Dynamic audio normalization - keeps everything at max volume
        filters.append("dynaudnorm=f=500:p=0.95:m=10:r=0.5:b=1")

        # Final hard limiter to prevent actual clipping distortion
        # while keeping the audio devastatingly loud
        filters.append("alimiter=limit=0.95:level=auto:attack=1:release=20")

        filter_str = ",".join(filters)
        logger.debug(f"Nuclear filter chain (level={level}, bass={bass}, mode={voice_mode}): {filter_str}")
        return filter_str

    @staticmethod
    def _bass_nuke(bass: float) -> list:
        """
        Multi-stage bass destruction.
        At bass=50, this produces bass so heavy it'll shake devices.
        """
        filters = []

        if bass <= 0:
            return filters

        # Stage 1: Primary bass boost with wide bandwidth for chest-thumping sub
        # bass=50 => gain=20dB which is absolutely devastating
        primary_gain = bass / 2.5  # bass=50 => 20dB, bass=100 => 40dB
        filters.append(f"bass=g={primary_gain}:f=60:w=0.8")

        # Stage 2: Sub-harmonic bass - the frequencies that vibrate your skull
        sub_gain = bass / 3.0  # bass=50 => ~17dB
        filters.append(f"bass=g={sub_gain}:f=40:w=0.6")

        # Stage 3: Parametric EQ boost at 80Hz - the "punch you in the chest" frequency
        eq_gain = bass / 4.0  # bass=50 => 12.5dB
        filters.append(f"aequalizer=80:1.5:{eq_gain}")

        # Stage 4: Parametric EQ boost at 120Hz - the "rumble your table" frequency
        eq_gain2 = bass / 5.0  # bass=50 => 10dB
        filters.append(f"aequalizer=120:1.0:{eq_gain2}")

        # Stage 5: Sub-bass emphasis below 80Hz for the deepest rumble
        filters.append(f"aequalizer=50:2.0:{bass / 3.5}")

        return filters

    @staticmethod
    def _compression_nuke(level: int) -> list:
        """
        Multi-stage compression that makes EVERY word hit like a sledgehammer.
        Quiet whispers become thunder. Normal speech becomes weaponized.
        """
        filters = []

        # Stage 1: Heavy upward compression - brings up quiet sounds dramatically
        # This ensures even whispers are heard at devastating volume
        filters.append("acompressor=threshold=-30dB:ratio=6:attack=1:release=50:makeup=8")

        # Stage 2: Peak compression - controls the peaks but keeps them loud
        filters.append("acompressor=threshold=-10dB:ratio=3:attack=2:release=80:makeup=4")

        # Stage 3: Limiting compression for the final punch
        filters.append("acompressor=threshold=-3dB:ratio=2:attack=0.5:release=100:makeup=2")

        # Stage 4: Multiband-style effect using low-shelf + presence boost
        # Boosts the vocal presence range (2-5kHz) for intelligibility
        filters.append("aequalizer=3000:2.0:6")

        return filters

    @staticmethod
    def _robot_filter() -> list:
        """
        Robot voice effect - metallic, robotic, terrifying.
        Uses ring modulation + formant shifting + phase vocoder.
        """
        filters = []
        # Ring modulation at 150Hz for metallic effect
        filters.append("afir=g=1:taps=512")
        # Phase shift for robotic quality
        filters.append("aphaser=type=tri:speed=0.5:decay=0.4")
        # Formant shift for unnatural vocal quality
        filters.append("aecho=0.8:0.88:5:0.5")
        filters.append("aecho=0.6:0.7:12:0.3")
        # Vibrato for mechanical feel
        filters.append("vibrato=f=5:d=0.5")
        # Bandpass for telephone-robotic effect
        filters.append("bandpass=f=1200:width_type=h:width=800")
        return filters

    @staticmethod
    def _whisper_filter() -> list:
        """
        Whisper mode - haunting, creepy, intimate.
        Removes low frequencies, adds breathiness and reverb.
        Still devastating at high levels.
        """
        filters = []
        # High-pass to remove bass
        filters.append("highpass=f=800")
        # Add breathiness with noise modulation
        filters.append("asetrate=r=48000*0.8,aresample=48000")
        # Subtle reverb for haunting effect
        filters.append("aecho=0.9:0.85:30:0.4")
        filters.append("aecho=0.8:0.8:60:0.3")
        filters.append("aecho=0.7:0.75:90:0.2")
        # Presence boost so whisper is still clear
        filters.append("aequalizer=4000:2.0:8")
        # Soft limiter
        filters.append("alimiter=limit=0.9:attack=5:release=50")
        return filters

    @staticmethod
    def _shout_filter() -> list:
        """
        Shout mode - MAXIMUM AGGRESSION.
        Like screaming through a megaphone at a stadium.
        The audio equivalent of a sledgehammer.
        """
        filters = []
        # Distortion - the classic "scream" effect
        filters.append("acrusher=bits=8:mode=log:aa=1")
        # Overdrive for aggression
        filters.append("afilter=0.1")
        # Heavy compression - makes everything LOUD
        filters.append("acompressor=threshold=-40dB:ratio=10:attack=0.1:release=20:makeup=15")
        # Bass boost for power
        filters.append("bass=g=15:f=80:w=0.8")
        # Mid-range boost for aggression (1-3kHz = the "bite" range)
        filters.append("aequalizer=1500:2.0:12")
        filters.append("aequalizer=2500:1.5:8")
        # Presence boost
        filters.append("aequalizer=5000:1.0:6")
        # Remove sub-bass that muddies the shout
        filters.append("highpass=f=100")
        # Megaphone/resonance effect
        filters.append("bandpass=f=1500:width_type=h:width=2000")
        return filters

    @staticmethod
    def _echo_filter(echo: float) -> list:
        """
        Multi-tap echo effect - from subtle to stadium reverb.
        """
        filters = []
        if echo <= 0:
            return filters

        # Calculate parameters based on echo intensity
        delay1 = int(30 + (echo * 0.3))
        delay2 = int(60 + (echo * 0.5))
        delay3 = int(100 + (echo * 0.8))
        decay = max(0.2, min(0.9, echo / 100))

        # Multi-tap echo for richness
        filters.append(f"aecho=0.9:0.9:{delay1}:{decay}")
        filters.append(f"aecho=0.8:0.85:{delay2}:{decay * 0.7}")
        filters.append(f"aecho=0.7:0.8:{delay3}:{decay * 0.5}")

        return filters

    @staticmethod
    def get_level_volume(level: int) -> float:
        """Get the volume multiplier for a given level (1-25)."""
        return NuclearAudioProcessor.LEVEL_MAP.get(level, 9.0)

    @staticmethod
    def get_bass_db(bass: float) -> float:
        """Get the primary bass gain in dB."""
        return bass / 2.5

    @staticmethod
    def get_preset(preset_name: str) -> Dict:
        """
        Get devastating preset configurations.
        Each preset is designed to maximize impact in its category.
        """
        presets = {
            "normal": {
                "level": 10, "bass": 50, "voice_mode": "normal",
                "echo": 0, "description": "Default devastating mode - bass=50 nuclear output"
            },
            "nuclear": {
                "level": 20, "bass": 80, "voice_mode": "shout",
                "echo": 30, "description": "MAXIMUM DESTRUCTION - do not use near speakers"
            },
            "earthquake": {
                "level": 25, "bass": 100, "voice_mode": "normal",
                "echo": 0, "description": "Pure bass annihilation - level 25 bass 100"
            },
            "demon": {
                "level": 18, "bass": 60, "voice_mode": "robot",
                "echo": 20, "description": "Demonic robot voice from hell"
            },
            "ghost": {
                "level": 12, "bass": 20, "voice_mode": "whisper",
                "echo": 50, "description": "Haunting whisper with long echo"
            },
            "stadium": {
                "level": 15, "bass": 40, "voice_mode": "echo",
                "echo": 80, "description": "Stadium echo effect with heavy bass"
            },
            "clean": {
                "level": 5, "bass": 10, "voice_mode": "normal",
                "echo": 0, "description": "Clean boosted audio - less destructive"
            },
        }
        return presets.get(preset_name, presets["normal"])
