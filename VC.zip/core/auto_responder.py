"""
VCFight V3 - Smart Auto Responder
Monitors messages in VCs and responds automatically.
"""

import asyncio
import logging
import time
from typing import Dict, Optional
from pyrogram import Client
from pyrogram.types import Message
from config.settings import OWNER_ID

logger = logging.getLogger(__name__)


class AutoResponder:
    """
    Smart auto-responder for voice chat messages.
    Can respond to triggers with text or voice messages.
    Includes intelligent mute control.
    """

    def __init__(self, db):
        self.db = db
        self.smart_mute_enabled: Dict[int, bool] = {}  # chat_id -> enabled
        self.response_cooldowns: Dict[str, float] = {}  # trigger -> last_response_time
        self.cooldown_seconds = 5  # Minimum time between same responses

    def is_smart_mute(self, chat_id: int) -> bool:
        return self.smart_mute_enabled.get(chat_id, False)

    def toggle_smart_mute(self, chat_id: int) -> bool:
        current = self.smart_mute_enabled.get(chat_id, False)
        self.smart_mute_enabled[chat_id] = not current
        return self.smart_mute_enabled[chat_id]

    async def check_and_respond(self, client: Client, message: Message) -> Optional[str]:
        """
        Check if a message matches any auto-response trigger.
        Returns the response if found, None otherwise.
        """
        if not message.text:
            return None

        text = message.text.strip()
        response = self.db.find_response(text)

        if response:
            # Check cooldown
            trigger_key = f"{message.chat.id}_{text[:30]}"
            last_time = self.response_cooldowns.get(trigger_key, 0)
            current_time = time.time()

            if current_time - last_time < self.cooldown_seconds:
                return None  # Still in cooldown

            self.response_cooldowns[trigger_key] = current_time
            return response

        return None

    def get_stats(self) -> dict:
        """Get auto-responder statistics."""
        responses = self.db.get_responses()
        return {
            'total_responses': len(responses),
            'smart_mute_chats': len([c for c, e in self.smart_mute_enabled.items() if e]),
            'active_cooldowns': len(self.response_cooldowns),
        }
