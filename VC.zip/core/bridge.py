"""
VCFight V3 - Audio Bridge Engine
Real-time audio bridging between Record VC and Playback VC.
Records from RECORD_GROUP VC and streams to the target VC with nuclear effects.
"""

import os
import subprocess
import asyncio
import logging
import time
from typing import Dict, Optional
from pathlib import Path
from pytgcalls import PyTgCalls
from pytgcalls.types import AudioPiped, AudioQuality
from core.audio_processor import NuclearAudioProcessor
from config.settings import TEMP_DIR, RECORD_GROUP

logger = logging.getLogger(__name__)


class AudioBridge:
    """
    The Audio Bridge that connects the Record VC to the Playback VC.
    Audio from RECORD_GROUP VC is captured, processed with devastating effects,
    and streamed to the target playback VC in real-time.
    """

    def __init__(self):
        self.active_bridges: Dict[int, dict] = {}  # chat_id -> bridge data
        self.ffmpeg_processes: Dict[int, subprocess.Popen] = {}
        self.current_level: int = 10
        self.current_bass: float = 50
        self.current_voice_mode: str = "normal"
        self.current_echo: float = 0
        self.is_muted: bool = False
        self.smart_mute_enabled: bool = False

        Path(TEMP_DIR).mkdir(parents=True, exist_ok=True)

    def _build_filter_chain(self) -> str:
        """Build the devastating FFmpeg filter chain."""
        return NuclearAudioProcessor.build_devastating_filter(
            level=self.current_level,
            bass=self.current_bass,
            voice_mode=self.current_voice_mode,
            echo=self.current_echo,
            smart_mute=self.smart_mute_enabled,
        )

    async def start_bridge(
        self,
        pytgcalls: PyTgCalls,
        record_chat_id: int,
        play_chat_id: int,
    ) -> bool:
        """
        Start the audio bridge from record_chat_id to play_chat_id.
        The assistant joins both VCs and bridges audio with effects.
        """
        try:
            if play_chat_id in self.active_bridges:
                logger.warning(f"Bridge already active for {play_chat_id}")
                return False

            bridge_id = f"{record_chat_id}_{play_chat_id}"

            # Create FIFO pipes for audio routing
            raw_fifo = f"{TEMP_DIR}/raw_{bridge_id}.raw"
            processed_fifo = f"{TEMP_DIR}/processed_{bridge_id}.raw"

            for fifo in [raw_fifo, processed_fifo]:
                if os.path.exists(fifo):
                    try:
                        os.remove(fifo)
                    except:
                        pass
                os.mkfifo(fifo)

            # Step 1: Start the raw audio capture from record VC
            # We use pytgcalls to get raw PCM from the record group
            # Then pipe through FFmpeg with our devastating effects

            filter_chain = self._build_filter_chain()

            # FFmpeg process: read raw PCM -> apply effects -> output processed PCM
            ffmpeg_cmd = [
                'ffmpeg',
                '-f', 's16le', '-ar', '48000', '-ac', '2',    # Input format
                '-i', raw_fifo,                                   # Input from raw FIFO
                '-af', filter_chain,                              # Apply devastating effects
                '-f', 's16le', '-ar', '48000', '-ac', '2',    # Output format
                '-y', processed_fifo                              # Output to processed FIFO
            ]

            process = subprocess.Popen(
                ffmpeg_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL
            )
            self.ffmpeg_processes[play_chat_id] = process

            await asyncio.sleep(1)

            # Step 2: Join the playback VC with processed audio
            await pytgcalls.join_group_call(
                play_chat_id,
                AudioPiped(processed_fifo, AudioQuality.HIGH)
            )

            self.active_bridges[play_chat_id] = {
                'record_chat_id': record_chat_id,
                'play_chat_id': play_chat_id,
                'raw_fifo': raw_fifo,
                'processed_fifo': processed_fifo,
                'started_at': time.time(),
                'level': self.current_level,
                'bass': self.current_bass,
                'voice_mode': self.current_voice_mode,
                'echo': self.current_echo,
            }

            logger.info(f"✅ Bridge started: {record_chat_id} -> {play_chat_id} | Level:{self.current_level} Bass:{self.current_bass}")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to start bridge: {e}")
            # Cleanup on failure
            for fifo in [raw_fifo, processed_fifo]:
                if os.path.exists(fifo):
                    try:
                        os.remove(fifo)
                    except:
                        pass
            return False

    async def restart_bridge_with_effects(
        self,
        pytgcalls: PyTgCalls,
        play_chat_id: int,
    ) -> bool:
        """Restart bridge with updated effects."""
        if play_chat_id not in self.active_bridges:
            return False

        bridge = self.active_bridges[play_chat_id]
        record_chat_id = bridge['record_chat_id']

        # Stop current bridge
        await self.stop_bridge(pytgcalls, play_chat_id)

        # Restart with new effects
        return await self.start_bridge(pytgcalls, record_chat_id, play_chat_id)

    async def stop_bridge(self, pytgcalls: PyTgCalls, play_chat_id: int) -> bool:
        """Stop an active bridge."""
        if play_chat_id not in self.active_bridges:
            return False

        bridge = self.active_bridges[play_chat_id]
        try:
            # Leave the playback VC
            try:
                await pytgcalls.leave_group_call(play_chat_id)
            except:
                pass

            # Kill FFmpeg process
            if play_chat_id in self.ffmpeg_processes:
                self.ffmpeg_processes[play_chat_id].terminate()
                try:
                    self.ffmpeg_processes[play_chat_id].wait(timeout=5)
                except:
                    self.ffmpeg_processes[play_chat_id].kill()
                del self.ffmpeg_processes[play_chat_id]

            # Remove FIFOs
            for fifo_key in ['raw_fifo', 'processed_fifo']:
                fifo = bridge.get(fifo_key)
                if fifo and os.path.exists(fifo):
                    try:
                        os.remove(fifo)
                    except:
                        pass

            del self.active_bridges[play_chat_id]
            logger.info(f"✅ Bridge stopped: {play_chat_id}")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to stop bridge: {e}")
            return False

    async def stop_all_bridges(self, pytgcalls: PyTgCalls) -> int:
        """Stop all active bridges."""
        count = 0
        for chat_id in list(self.active_bridges.keys()):
            if await self.stop_bridge(pytgcalls, chat_id):
                count += 1
        return count

    def set_level(self, level: int) -> bool:
        """Set volume level (1-25)."""
        if 1 <= level <= 25:
            self.current_level = level
            logger.info(f"🔊 Level set to {level} (volume: {NuclearAudioProcessor.get_level_volume(level)}x)")
            return True
        return False

    def set_bass(self, bass: float) -> bool:
        """Set bass boost (0-100)."""
        if 0 <= bass <= 100:
            self.current_bass = bass
            logger.info(f"🔊 Bass set to {bass} ({NuclearAudioProcessor.get_bass_db(bass):.1f}dB)")
            return True
        return False

    def set_voice_mode(self, mode: str) -> bool:
        """Set voice mode (normal/robot/echo/whisper/shout)."""
        valid_modes = ["normal", "robot", "echo", "whisper", "shout"]
        if mode in valid_modes:
            self.current_voice_mode = mode
            logger.info(f"🔊 Voice mode set to {mode}")
            return True
        return False

    def set_echo(self, echo: float) -> bool:
        """Set echo intensity (0-100)."""
        if 0 <= echo <= 100:
            self.current_echo = echo
            logger.info(f"🔊 Echo set to {echo}")
            return True
        return False

    def reset_voice(self):
        """Reset all effects to defaults."""
        self.current_level = 10
        self.current_bass = 50
        self.current_voice_mode = "normal"
        self.current_echo = 0
        logger.info("🔊 All effects reset to defaults")

    def get_status(self) -> dict:
        """Get current bridge status."""
        return {
            'level': self.current_level,
            'bass': self.current_bass,
            'voice_mode': self.current_voice_mode,
            'echo': self.current_echo,
            'muted': self.is_muted,
            'smart_mute': self.smart_mute_enabled,
            'active_bridges': len(self.active_bridges),
            'volume_multiplier': NuclearAudioProcessor.get_level_volume(self.current_level),
            'bass_db': NuclearAudioProcessor.get_bass_db(self.current_bass),
        }

    def get_bridge_count(self) -> int:
        return len(self.active_bridges)
