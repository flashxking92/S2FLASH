"""
VCFight V3 - Core Module
"""

from .assistant import AssistantManager
from .bridge import AudioBridge
from .database import DatabaseManager
from .audio_processor import NuclearAudioProcessor
from .auto_responder import AutoResponder
from .health import HealthMonitor

__version__ = "3.0.0"
__codename__ = "Nuclear Edition"

__all__ = [
    'AssistantManager',
    'AudioBridge',
    'DatabaseManager',
    'NuclearAudioProcessor',
    'AutoResponder',
    'HealthMonitor',
]
