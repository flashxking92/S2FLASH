#!/usr/bin/env python3
"""
VCFight V3 - Startup Validation
Check all dependencies before starting the bot.
"""

import sys
import subprocess
import shutil
import os
from pathlib import Path


def check_python_version():
    version = sys.version_info
    if version.major >= 3 and version.minor >= 10:
        print(f"  ✅ Python {version.major}.{version.minor}.{version.micro}")
        return True
    print(f"  ❌ Python 3.10+ required (found {version.major}.{version.minor})")
    return False


def check_ffmpeg():
    if shutil.which('ffmpeg'):
        result = subprocess.run(['ffmpeg', '-version'], capture_output=True, text=True)
        version_line = result.stdout.split('\n')[0]
        print(f"  ✅ {version_line[:60]}")
        return True
    print("  ❌ FFmpeg not found! Install: sudo apt install ffmpeg")
    return False


def check_packages():
    required = ['pyrogram', 'pytgcalls', 'sqlalchemy', 'pydub', 'yt_dlp', 'dotenv']
    missing = []

    for pkg in required:
        try:
            __import__(pkg.replace('dotenv', 'dotenv'))
            print(f"  ✅ {pkg}")
        except ImportError:
            missing.append(pkg)
            print(f"  ❌ {pkg}")

    return len(missing) == 0


def check_env():
    from dotenv import load_dotenv
    load_dotenv()

    # Check env file
    env_path = Path("env")
    if env_path.exists():
        print("  ✅ env file found")
    else:
        print("  ⚠️ No env file found - using environment variables")

    required_vars = ['API_ID', 'API_HASH', 'BOT_TOKEN', 'OWNER_ID']
    missing = []

    for var in required_vars:
        value = os.getenv(var)
        if value and value not in ['', '0']:
            if var in ['API_HASH', 'BOT_TOKEN']:
                print(f"  ✅ {var} = {value[:10]}...")
            else:
                print(f"  ✅ {var} = {value}")
        else:
            missing.append(var)
            print(f"  ⚠️ {var} - NOT SET (set in env file before running)")

    return True  # Don't block startup for env vars


def check_directories():
    dirs = ['logs', 'downloads', 'sessions', '/tmp/vcfight_v3']
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)
        print(f"  ✅ Directory: {d}")
    return True


def main():
    print("\n" + "☢️" * 30)
    print("☢️ VCFight V3 - Startup Validation")
    print("☢️" * 30 + "\n")

    checks = [
        ("Python Version", check_python_version()),
        ("FFmpeg", check_ffmpeg()),
        ("Python Packages", check_packages()),
        ("Environment", check_env()),
        ("Directories", check_directories()),
    ]

    print("\n" + "☢️" * 30)
    critical_passed = checks[0][1] and checks[1][1] and checks[2][1]

    if critical_passed:
        print("✅ CRITICAL CHECKS PASSED! Ready to start.")
        print("☢️" * 30 + "\n")
        return 0
    else:
        print("❌ SOME CHECKS FAILED!")
        print("\n💡 Quick Fix:")
        print("  • pip install -r requirements.txt")
        print("  • sudo apt install ffmpeg")
        print("  • Fill in the env file with your credentials")
        print("☢️" * 30 + "\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
