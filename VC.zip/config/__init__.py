"""
VCFight V3 - Configuration Module
"""

from .settings import *

__all__ = [
    'API_ID', 'API_HASH', 'BOT_TOKEN', 'OWNER_ID',
    'SUDO_USERS', 'STRING_SESSION', 'RECORD_GROUP', 'LOGGER_GROUP',
    'AUDIO_BITRATE', 'AUDIO_CHANNELS',
    'DEFAULT_GAIN', 'DEFAULT_BASS', 'DEFAULT_ECHO', 'DEFAULT_LOUDNESS',
    'MIN_LEVEL', 'MAX_LEVEL', 'DEFAULT_LEVEL',
    'DATABASE_URL', 'LOG_LEVEL', 'TEMP_DIR', 'SESSION_PREFIX', 'MAX_BRIDGES',
    'is_owner', 'is_sudo',
]
