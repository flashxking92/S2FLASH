import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

# ==================== TELEGRAM CONFIGURATION ====================
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
SUDO_USERS = [OWNER_ID] + [int(x.strip()) for x in os.getenv("SUDO_USERS", "").split(",") if x.strip()]
STRING_SESSION = os.getenv("STRING_SESSION", "")
RECORD_GROUP = int(os.getenv("RECORD_GROUP", "-1002930799867"))
LOGGER_GROUP = int(os.getenv("LOGGER_GROUP", "-1002930799867"))

# ==================== AUDIO CONFIGURATION ====================
AUDIO_BITRATE = int(os.getenv("AUDIO_BITRATE", "48000"))
AUDIO_CHANNELS = int(os.getenv("AUDIO_CHANNELS", "2"))

# ==================== DEVASTATING AUDIO PRESETS ====================
# The "Ass Ripper" default config - maximum devastation
DEFAULT_GAIN = int(os.getenv("DEFAULT_GAIN", "300"))
DEFAULT_BASS = int(os.getenv("DEFAULT_BASS", "50"))
DEFAULT_ECHO = int(os.getenv("DEFAULT_ECHO", "0"))
DEFAULT_LOUDNESS = int(os.getenv("DEFAULT_LOUDNESS", "80"))

# Volume level range
MIN_LEVEL = 1
MAX_LEVEL = 25
DEFAULT_LEVEL = 10

# ==================== DATABASE CONFIGURATION ====================
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///vcfight_v3.db")

# ==================== LOGGING CONFIGURATION ====================
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# ==================== ADVANCED CONFIGURATION ====================
TEMP_DIR = os.getenv("TEMP_DIR", "/tmp/vcfight_v3")
SESSION_PREFIX = os.getenv("SESSION_PREFIX", "VCFight_")
MAX_BRIDGES = int(os.getenv("MAX_BRIDGES", "10"))

# Create directories
for d in [TEMP_DIR, "logs", "downloads", "sessions"]:
    Path(d).mkdir(parents=True, exist_ok=True)

# Logging setup
import logging
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/vcfight_v3.log'),
        logging.StreamHandler()
    ]
)

# ==================== SUDO/OWNER HELPERS ====================
def is_owner(user_id: int) -> bool:
    return user_id == OWNER_ID

def is_sudo(user_id: int) -> bool:
    return user_id in SUDO_USERS or user_id == OWNER_ID
