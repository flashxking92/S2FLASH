#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║              ☢️ VCFight V3 - Nuclear Edition ☢️          ║
║                                                          ║
║     The most devastating Telegram VC bot ever built.     ║
║     When this hits the VC, everyone feels it.            ║
║                                                          ║
║     Default: Level 10 + Bass 50 = DEVASTATION           ║
║     Maximum: Level 25 + Bass 100 = NUCLEAR              ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from pyrogram import Client, idle
from config.settings import (
    API_ID, API_HASH, BOT_TOKEN, OWNER_ID,
    STRING_SESSION, RECORD_GROUP, LOGGER_GROUP, SUDO_USERS
)
from core.assistant import AssistantManager
from core.bridge import AudioBridge
from core.database import DatabaseManager
from core.auto_responder import AutoResponder
from core.health import HealthMonitor
from plugins.session_commands import SessionCommands
from plugins.vc_commands import VCCommands
from plugins.voice_effects import VoiceEffectsCommands
from plugins.auto_responder import AutoResponderCommands
from plugins.owner_commands import OwnerCommands

logger = logging.getLogger(__name__)


class VCFightV3:
    """VCFight V3 - Nuclear Edition Bot"""

    def __init__(self):
        # Core bot
        self.bot = Client(
            "VCFightV3",
            api_id=API_ID,
            api_hash=API_HASH,
            bot_token=BOT_TOKEN,
        )

        # Core systems
        self.assistant_manager = AssistantManager(API_ID, API_HASH)
        self.audio_bridge = AudioBridge()
        self.db = DatabaseManager()
        self.auto_responder = AutoResponder(self.db)
        self.health = HealthMonitor()

    async def start(self):
        """Start the bot and all systems."""
        print("\n" + "☢️" * 30)
        print("☢️ VCFIGHT V3 - NUCLEAR EDITION")
        print("☢️" * 30)
        print(f"\n  Version: 3.0.0")
        print(f"  Codename: Nuclear Edition")
        print(f"  Owner ID: {OWNER_ID}")
        print(f"  Record Group: {RECORD_GROUP}")
        print(f"  Logger Group: {LOGGER_GROUP}")
        print(f"  Default Level: 10 (9.0x volume)")
        print(f"  Default Bass: 50 (20.0dB)")
        print()
        print("  Features:")
        print("  ☢️ Nuclear Audio Processor - devastating filter chains")
        print("  🎙 Audio Bridge - Record VC → Play VC with effects")
        print("  🤖 Voice Effects - Robot, Echo, Whisper, Shout")
        print("  🎵 Bass Boost - Default 50, Max 100")
        print("  🔊 Volume Level - 1-25 (up to 45x multiplier)")
        print("  🧠 Auto Responder - Smart message responses")
        print("  📊 Voice Stats - Track usage and performance")
        print("  🏥 Health Monitor - System diagnostics")
        print("  👑 Owner Commands - Full bot management")
        print()
        print("☢️" * 30 + "\n")

        # Start bot
        await self.bot.start()
        me = await self.bot.get_me()
        print(f"✅ Bot started: @{me.username}\n")

        # Restore assistants from database
        assistants = self.db.get_assistants()
        if assistants:
            print(f"📂 Restoring {len(assistants)} assistant(s)...")
            for ass in assistants:
                try:
                    result = await self.assistant_manager.add_assistant(
                        ass.session_string, ass.name
                    )
                    if result:
                        print(f"  ✅ Restored: {ass.name}")
                    else:
                        print(f"  ❌ Failed: {ass.name} (session may be revoked)")
                except Exception as e:
                    print(f"  ❌ Error: {ass.name} - {e}")
        else:
            print("⚠️ No assistants found!")
            if STRING_SESSION:
                print("🔑 Attempting to load STRING_SESSION from env...")
                result = await self.assistant_manager.add_assistant(STRING_SESSION)
                if result:
                    self.db.save_assistant(
                        STRING_SESSION, result['name'],
                        result['user_id'], result.get('username')
                    )
                    print(f"  ✅ Loaded: {result['name']}")
                else:
                    print("  ❌ Failed to load STRING_SESSION")

        # Initialize all plugins
        print("\n🔧 Initializing plugins...")
        SessionCommands(self.bot, self.assistant_manager, self.db, self.health)
        print("  ✅ Session commands")
        VCCommands(self.bot, self.assistant_manager, self.audio_bridge, self.db, self.health)
        print("  ✅ VC commands")
        VoiceEffectsCommands(self.bot, self.assistant_manager, self.audio_bridge, self.db, self.health)
        print("  ✅ Voice effects")
        AutoResponderCommands(self.bot, self.auto_responder, self.db, self.health)
        print("  ✅ Auto responder")
        OwnerCommands(self.bot, self.assistant_manager, self.audio_bridge, self.db, self.health)
        print("  ✅ Owner commands")

        # Register auto-responder message handler
        @self.bot.on_message(filters.group & filters.text & ~filters.command(
            ["join", "record", "level", "bass", "mute", "unmute",
             "leaverecord", "leaveplay", "robot", "echo", "whisper",
             "shout", "resetvoice", "preset", "effects", "addresponse",
             "listresponses", "delresponse", "smartmute", "voicestats",
             "addsession", "delsession", "status", "setrecordgroup",
             "addsudo", "delsudo", "listsudo", "sessions", "health",
             "uptime", "broadcast", "restart"]
        ))
        async def auto_responder_handler(client, message):
            response = await self.auto_responder.check_and_respond(client, message)
            if response:
                await message.reply(response)

        print("\n" + "☢️" * 30)
        print("☢️ VCFIGHT V3 IS ONLINE AND READY! ☢️")
        print("☢️" * 30)
        print(f"""
  📋 Available Commands:

  🔧 Session Management (Sudo):
     /addsession - Add assistant session (PM)
     /delsession - Delete session (PM)
     /status - Check session status
     /setrecordgroup - Set record group

  🎙 VC Controls:
     /join - Join VC (assistant joins this chat's VC)
     /record - Start audio bridge from record group
     /level <1-25> - Set volume level
     /bass <0-100> - Set bass boost
     /mute - Mute playback VC
     /unmute - Unmute playback VC
     /leaverecord - Leave record VC
     /leaveplay - Leave playback VC + stop bridge

  🎭 Voice Effects:
     /robot - Robotic voice effect
     /echo [0-100] - Echo effect
     /whisper - Whisper mode
     /shout - Shout mode (MAXIMUM AGGRESSION)
     /resetvoice - Reset to default
     /preset <name> - Apply preset (nuclear/earthquake/demon/ghost/stadium/clean/normal)
     /effects - Show effects dashboard

  🤖 Auto Responder:
     /addresponse trigger | response
     /listresponses - List all responses
     /delresponse ID - Delete response
     /smartmute - Toggle smart mute
     /voicestats - Show voice statistics

  👑 Owner Only:
     /addsudo - Add sudo user
     /delsudo - Remove sudo user
     /listsudo - List sudo users
     /sessions - List active sessions
     /health - Bot health report
     /uptime - Bot uptime
     /broadcast - Broadcast message
     /restart - Restart bot
""")
        print("☢️" * 30 + "\n")

        # Log startup
        try:
            await self.bot.send_message(
                LOGGER_GROUP,
                f"☢️ **VCFight V3 Started!**\n\n"
                f"**Version:** 3.0.0 Nuclear Edition\n"
                f"**Assistants:** {self.assistant_manager.get_assistant_count()}\n"
                f"**Default Level:** 10 (9.0x)\n"
                f"**Default Bass:** 50 (20.0dB)"
            )
        except:
            pass

        # Keep running
        await idle()

        # Cleanup on shutdown
        print("\n🛑 Shutting down...")
        assistant = self.assistant_manager.get_primary()
        if assistant:
            await self.audio_bridge.stop_all_bridges(assistant['bridge'])
        await self.bot.stop()
        print("👋 Goodbye!")


async def main():
    try:
        bot = VCFightV3()
        await bot.start()
    except KeyboardInterrupt:
        print("\n👋 Bot stopped by user")
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
