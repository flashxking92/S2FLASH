# ☢️ VCFight V3 - Nuclear Edition ☢️

**The most devastating Telegram Voice Chat bot ever built.**

When this bot hits the VC, everyone feels it. Default configuration: Level 10 + Bass 50 = DEVASTATION. Maximum: Level 25 + Bass 100 = NUCLEAR.

---

## 🔥 Features

### Nuclear Audio Processor
Multi-stage FFmpeg filter chain that processes audio through 7 devastating phases:
1. **Input Conditioning** - Frequency cleanup for maximum clarity
2. **Voice Mode Effects** - Robot, Echo, Whisper, Shout transformations
3. **Nuclear Bass Boost** - 5-stage bass destruction (sub-bass → parametric EQ → skull vibration)
4. **Multi-Stage Compression** - 4-stage compression that makes whispers hit like thunder
5. **Loudness Maximization** - EBU R128 normalization at -6 LUFS
6. **Level-Based Volume** - /level 1-25 maps to 1x-45x multipliers
7. **Final Polish** - Dynamic normalization + hard limiting for maximum loudness

### Audio Bridge
Real-time audio bridging between Record VC and Playback VC:
- Speak in RECORD_GROUP VC → Audio processed with effects → Played in target VC
- Zero-latency FFmpeg processing pipeline
- Automatic VC join/leave management

### Voice Effects
- **Robot** - Metallic, robotic voice with ring modulation
- **Echo** - Multi-tap echo from subtle to stadium
- **Whisper** - Haunting, intimate whisper mode
- **Shout** - Maximum aggression with distortion + overdrive

### Volume Levels (1-25)
| Level | Multiplier | Description |
|-------|-----------|-------------|
| 1-5 | 1.0-3.5x | Normal volume |
| 6-10 | 4.5-9.0x | Loud (default: 10) |
| 11-15 | 10.5-17.0x | Very loud |
| 16-20 | 19.0-27.5x | Extremely loud |
| 21-25 | 30.0-45.0x | ☢️ NUCLEAR |

### Bass Boost (0-100)
At default **bass=50**, the output produces 20dB of bass boost across 5 stages:
- Primary bass boost at 60Hz
- Sub-harmonic bass at 40Hz
- Parametric EQ punch at 80Hz
- Rumble EQ at 120Hz
- Sub-bass emphasis at 50Hz

### Presets
- `/preset nuclear` - Level 20 + Bass 80 + Shout mode
- `/preset earthquake` - Level 25 + Bass 100 (pure bass destruction)
- `/preset demon` - Level 18 + Robot mode
- `/preset ghost` - Level 12 + Whisper mode
- `/preset stadium` - Level 15 + Echo 80%
- `/preset normal` - Default devastating mode
- `/preset clean` - Reduced intensity

---

## 🚀 Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
sudo apt install ffmpeg
```

### 2. Configure Environment
Edit the `env` file:
```
API_ID=your_api_id
API_HASH=your_api_hash
BOT_TOKEN=your_bot_token
OWNER_ID=your_user_id
STRING_SESSION=your_assistant_session
RECORD_GROUP=-1002930799867
LOGGER_GROUP=-1002930799867
```

### 3. Generate Session String
```bash
python gen_string.py
```
Enter the API ID, API Hash, and login with the assistant account's phone number. Copy the session string.

### 4. Run the Bot
```bash
python main.py
```

Or with Docker:
```bash
docker build -t vcfight-v3 .
docker run -d --env-file env vcfight-v3
```

---

## 📋 Commands

### 🔧 Session Management (Sudo)
| Command | Description |
|---------|-------------|
| `/addsession` | Add assistant session (PM only) |
| `/delsession` | Delete session (PM only) |
| `/status` | Check session status |
| `/setrecordgroup` | Set record group (Owner only) |

### 🎙 VC Controls
| Command | Description |
|---------|-------------|
| `/join` | Join VC (assistant joins this chat's VC) |
| `/record` | Start audio bridge from record group |
| `/level <1-25>` | Set volume level |
| `/bass <0-100>` | Set bass boost |
| `/mute` | Mute playback VC |
| `/unmute` | Unmute playback VC |
| `/leaverecord` | Leave record VC |
| `/leaveplay` | Leave playback VC + stop bridge |

### 🎭 Voice Effects
| Command | Description |
|---------|-------------|
| `/robot` | Robotic voice effect |
| `/echo [0-100]` | Echo effect |
| `/whisper` | Whisper mode |
| `/shout` | Shout mode (MAXIMUM AGGRESSION) |
| `/resetvoice` | Reset to default effects |
| `/preset <name>` | Apply preset |
| `/effects` | Show effects dashboard |

### 🤖 Auto Responder
| Command | Description |
|---------|-------------|
| `/addresponse trigger \| response` | Add auto-response |
| `/listresponses` | List all responses |
| `/delresponse ID` | Delete response |
| `/smartmute` | Toggle smart mute |
| `/voicestats` | Show voice statistics |

### 👑 Owner Only
| Command | Description |
|---------|-------------|
| `/addsudo` | Add sudo user |
| `/delsudo` | Remove sudo user |
| `/listsudo` | List sudo users |
| `/sessions` | List active sessions |
| `/health` | Bot health report |
| `/uptime` | Bot uptime |
| `/broadcast` | Broadcast message |
| `/restart` | Restart bot |

---

## 🎯 Usage Flow

1. **Add Assistant**: Use `/addsession` in PM with the session string
2. **Add to Groups**: Add the assistant account to both the record group and target group
3. **Join VC**: In the target group, use `/join` - assistant joins that VC
4. **Start Bridge**: Use `/record` - audio from record group VC is now streamed to target VC with effects
5. **Adjust Effects**: Use `/level`, `/bass`, `/robot`, `/shout`, etc. to customize
6. **Speak**: Talk in the record group VC - your voice comes out in the target VC with devastating effects!

---

## ⚠️ Warnings

- **Level 20+** may damage speakers and headphones
- **Bass 80+** can cause device vibration and distortion on low-quality speakers
- **Shout mode** adds heavy distortion and compression
- Use responsibly and at your own risk

---

## 📱 Device Compatibility

Tested for: Vivo V30E (V2339), Android 15, Snapdragon 6 Gen 1, 8+8GB RAM

Works on any device/platform that can run Python 3.10+ with FFmpeg.

---

## 📄 License

Educational purposes only.
