import os
import re
from dotenv import load_dotenv
from pyrogram import filters

load_dotenv()

# ================= CORE CONFIG =================

API_ID = int(os.getenv("API_ID", 0))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")

OWNER_ID = int(os.getenv("OWNER_ID", 0))
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "Why_not_zarko")
BOT_USERNAME = os.getenv("BOT_USERNAME", "ZarkoMusicBot")

# ================= DATABASE =================

MONGO_DB_URI = os.getenv("MONGO_DB_URI", "")
LOG_GROUP_ID = int(os.getenv("LOG_GROUP_ID", 0))

# ================= LINKS =================

SUPPORT_CHANNEL = os.getenv("SUPPORT_CHANNEL", "")
SUPPORT_GROUP = os.getenv("SUPPORT_GROUP", "")

INSTAGRAM = os.getenv("INSTAGRAM", "")
YOUTUBE = os.getenv("YOUTUBE", "")
GITHUB = os.getenv("GITHUB", "")
DONATE = os.getenv("DONATE", "")
PRIVACY_LINK = os.getenv("PRIVACY_LINK", "")

# ================= LIMITS =================

DURATION_LIMIT_MIN = int(os.getenv("DURATION_LIMIT", 300))
PLAYLIST_FETCH_LIMIT = int(os.getenv("PLAYLIST_FETCH_LIMIT", 25))

TG_AUDIO_FILESIZE_LIMIT = int(os.getenv("TG_AUDIO_FILESIZE_LIMIT", 104857600))
TG_VIDEO_FILESIZE_LIMIT = int(os.getenv("TG_VIDEO_FILESIZE_LIMIT", 2145386496))

# ================= SPOTIFY =================

SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID", "")
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET", "")

# ================= ASSISTANT =================

STRING1 = os.getenv("STRING_SESSION")
STRING2 = os.getenv("STRING_SESSION2")
STRING3 = os.getenv("STRING_SESSION3")
STRING4 = os.getenv("STRING_SESSION4")
STRING5 = os.getenv("STRING_SESSION5")

# ================= FEATURES =================

UPSTREAM_REPO = "https://github.com/Why_not_zarko/ZarkoMusicBot"

AUTO_LEAVING_ASSISTANT = os.getenv("AUTO_LEAVING_ASSISTANT", "False").lower() == "true"

# ================= IMAGES =================

START_IMG_URL = os.getenv("START_IMG_URL", "https://files.catbox.moe/jl4ynl.png")

PING_IMG_URL = "https://files.catbox.moe/h3zorj.png"
PLAYLIST_IMG_URL = "https://files.catbox.moe/h3zorj.png"
STATS_IMG_URL = "https://files.catbox.moe/h3zorj.png"
TELEGRAM_AUDIO_URL = "https://files.catbox.moe/h3zorj.png"
TELEGRAM_VIDEO_URL = "https://files.catbox.moe/h3zorj.png"
STREAM_IMG_URL = "https://files.catbox.moe/h3zorj.png"
SOUNDCLOUD_IMG_URL = "https://files.catbox.moe/h3zorj.png"
YOUTUBE_IMG_URL = "https://files.catbox.moe/h3zorj.png"
SPOTIFY_ARTIST_IMG_URL = "https://files.catbox.moe/h3zorj.png"
SPOTIFY_ALBUM_IMG_URL = "https://files.catbox.moe/h3zorj.png"
SPOTIFY_PLAYLIST_IMG_URL = "https://files.catbox.moe/h3zorj.png"

# ================= DOWNLOADER =================

VID_API_TOKEN = os.getenv("VID_API_TOKEN", "c99f113fab0762d216b4545e5c3d615eefb30f0975fe107caab629d17e51b52d")

# ================= RUNTIME =================

TEMP_DB_FOLDER = "tempdb"

BANNED_USERS = filters.user()
adminlist = {}
lyrical = {}
votemode = {}
autoclean = []
confirmer = {}

# ================= FUNCTIONS =================

def time_to_seconds(time):
    stringt = str(time)
    return sum(int(x) * 60**i for i, x in enumerate(reversed(stringt.split(":"))))

DURATION_LIMIT = DURATION_LIMIT_MIN * 60  # convert minutes → seconds

ERROR_FORMAT = 7574330905

# ================= VALIDATION =================

if SUPPORT_CHANNEL and not re.match(r"(?:http|https)://", SUPPORT_CHANNEL):
    raise SystemExit("Invalid SUPPORT_CHANNEL URL (must start with https://)")

if SUPPORT_GROUP and not re.match(r"(?:http|https)://", SUPPORT_GROUP):
    raise SystemExit("Invalid SUPPORT_GROUP URL (must start with https://)")