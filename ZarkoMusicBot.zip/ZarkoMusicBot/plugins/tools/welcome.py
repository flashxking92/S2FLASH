import os
from logging import getLogger

from PIL import Image, ImageDraw, ImageFont, ImageChops
from pyrogram import Client, filters, enums
from pyrogram.types import (
    ChatMemberUpdated,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from unidecode import unidecode

from ZarkoMusicBot import app
from ZarkoMusicBot.utils.database import db

LOGGER = getLogger(__name__)

try:
    wlcm = db.welcome
except Exception:
    from ZarkoMusicBot.utils.database import welcome as wlcm


# ──────────────────────────────────────────
#  TEMP STATE
# ──────────────────────────────────────────
class temp:
    ME = None
    CURRENT = 2
    CANCEL = False
    MELCOW = {}
    U_NAME = None
    B_NAME = None


# ──────────────────────────────────────────
#  SMALL CAPS CONVERTER  (ꜰʟᴀꜱʜ ꜱᴛʏʟᴇ)
# ──────────────────────────────────────────
_SC = str.maketrans(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ",
)


def sc(text: str) -> str:
    """Convert plain text to Unicode small-caps (ꜰʟᴀꜱʜ style)."""
    return text.translate(_SC)


# ──────────────────────────────────────────
#  CIRCULAR CROP HELPER
# ──────────────────────────────────────────
def circle(pfp: Image.Image, size: tuple = (554, 554)) -> Image.Image:
    """Crop image into a perfect circle."""
    pfp = pfp.resize(size, Image.LANCZOS).convert("RGBA")
    bigsize = (pfp.size[0] * 3, pfp.size[1] * 3)
    mask = Image.new("L", bigsize, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0) + bigsize, fill=255)
    mask = mask.resize(pfp.size, Image.LANCZOS)
    mask = ImageChops.darker(mask, pfp.split()[-1])
    pfp.putalpha(mask)
    return pfp


# ──────────────────────────────────────────
#  WELCOME IMAGE GENERATOR
#  Template: 1536 × 1024 px
#  Circle center: (1197, 469) | radius: 277
#  Paste offset : (920, 192)  | size  : 554
# ──────────────────────────────────────────
def welcomepic(
    pic: str,
    user: str,
    chat: str,
    user_id: int,
    uname: str,
) -> str:
    os.makedirs("downloads", exist_ok=True)

    # ── Background ──────────────────────────
    background = Image.open(
        "ZarkoMusicBot/assets/welcome.png"
    ).convert("RGBA")

    # ── Profile picture ─────────────────────
    try:
        pfp = Image.open(pic).convert("RGBA")
    except Exception:
        pfp = Image.open(
            "ZarkoMusicBot/assets/upic.png"
        ).convert("RGBA")

    pfp = circle(pfp, size=(554, 554))
    background.paste(pfp, (920, 192), pfp)

    # ── Drawing canvas ──────────────────────
    draw = ImageDraw.Draw(background)

    # ── Fonts ───────────────────────────────
    font_main = ImageFont.truetype(
        "ZarkoMusicBot/assets/font.ttf", 44
    )
    font_user = ImageFont.truetype(
        "ZarkoMusicBot/assets/font.ttf", 38
    )

    # ── Safe name (max 15 chars) ─────────────
    name = unidecode(user).strip() if user else "User"
    if len(name) > 15:
        name = name[:13] + "…"

    # ── Safe username ───────────────────────
    username_text = f"@{uname}" if uname else "ɴᴏᴛ ꜱᴇᴛ"

    # ── Draw values next to template labels ─
    #    NAME row  → y ≈ 463
    draw.text((360, 463), name, fill="white", font=font_main)

    #    ID row    → y ≈ 540
    draw.text((360, 540), str(user_id), fill="white", font=font_main)

    #    USERNAME  → y ≈ 618
    draw.text((360, 618), username_text, fill="white", font=font_user)

    # ── Save & return ───────────────────────
    output = f"downloads/welcome_{user_id}.png"
    background.save(output)
    return output


# ──────────────────────────────────────────
#  /welcome [on|off]  —  Admin Command
# ──────────────────────────────────────────
@app.on_message(filters.command("welcome") & ~filters.private)
async def auto_state(_, message):
    usage = f"/{sc('welcome')} [{sc('on')}|{sc('off')}]"

    if len(message.command) == 1:
        return await message.reply_text(usage)

    chat_id = message.chat.id

    member = await app.get_chat_member(
        message.chat.id,
        message.from_user.id,
    )

    if member.status not in (
        enums.ChatMemberStatus.ADMINISTRATOR,
        enums.ChatMemberStatus.OWNER,
    ):
        return await message.reply_text(
            f"✦ {sc('Only Admins Can Use This Command')}"
        )

    data = await wlcm.find_one({"chat_id": chat_id})
    state = message.text.split(None, 1)[1].strip().lower()

    if state == "on":
        if data and not data.get("disabled", False):
            return await message.reply_text(
                f"✦ {sc('Welcome Already Enabled')}"
            )
        await wlcm.update_one(
            {"chat_id": chat_id},
            {"$set": {"disabled": False}},
            upsert=True,
        )
        return await message.reply_text(
            f"✦ {sc('Special Welcome Enabled in')} {message.chat.title}"
        )

    elif state == "off":
        if data and data.get("disabled", False):
            return await message.reply_text(
                f"✦ {sc('Welcome Already Disabled')}"
            )
        await wlcm.update_one(
            {"chat_id": chat_id},
            {"$set": {"disabled": True}},
            upsert=True,
        )
        return await message.reply_text(
            f"✦ {sc('Special Welcome Disabled in')} {message.chat.title}"
        )

    else:
        return await message.reply_text(usage)


# ──────────────────────────────────────────
#  NEW MEMBER WELCOME HANDLER
# ──────────────────────────────────────────
@app.on_chat_member_updated(filters.group, group=-3)
async def greet_group(_, member: ChatMemberUpdated):

    chat_id = member.chat.id

    # ── Check DB for disabled state ─────────
    welcome_data = await wlcm.find_one({"chat_id": chat_id})
    if welcome_data and welcome_data.get("disabled", False):
        return

    # ── Only handle real joins ───────────────
    old_status = (
        member.old_chat_member.status
        if member.old_chat_member
        else None
    )
    new_status = (
        member.new_chat_member.status
        if member.new_chat_member
        else None
    )

    if not (
        old_status in (
            enums.ChatMemberStatus.LEFT,
            enums.ChatMemberStatus.BANNED,
            None,
        )
        and new_status in (
            enums.ChatMemberStatus.MEMBER,
            enums.ChatMemberStatus.ADMINISTRATOR,
        )
    ):
        return

    user = member.new_chat_member.user

    # ── Download profile picture ─────────────
    profile_pic = "ZarkoMusicBot/assets/upic.png"
    try:
        photo_list = []
        async for photo in app.get_chat_photos(user.id, limit=1):
            photo_list.append(photo)

        if photo_list:
            profile_pic = await app.download_media(
                photo_list[0].file_id,
                file_name=f"downloads/pp{user.id}.png",
            )
    except Exception as e:
        LOGGER.warning(f"Profile pic download failed: {e}")

    # ── Delete previous welcome message ──────
    prev_key = f"welcome-{chat_id}"
    if temp.MELCOW.get(prev_key) is not None:
        try:
            await temp.MELCOW[prev_key].delete()
        except Exception as e:
            LOGGER.error(f"Delete old welcome failed: {e}")

    # ── Generate & send welcome image ────────
    try:
        welcome_image = welcomepic(
            profile_pic,
            user.first_name,
            member.chat.title,
            user.id,
            user.username,
        )

        username_display = (
            f"@{user.username}" if user.username else sc("Not Set")
        )

        caption = f"""
☆•*´¨`*•.¸¸.•* {sc("Welcome")} *•.¸¸.•*´¨`*•☆

✨ **✦ {sc("Hey")} {user.mention} ✦** ✨

┏━━━━━━━━━━━━━━━━━━━━┓
┃ ✦ **{sc("Group")}**    : {member.chat.title}
┃ ✦ **{sc("User ID")}**  : `{user.id}`
┃ ✦ **{sc("Username")}** : {username_display}
┗━━━━━━━━━━━━━━━━━━━━┛

🌸 **{sc("Enjoy Music & Amazing Vibes")}** 🎵

｡ﾟ•┈୨♡୧┈•ﾟ｡
"""

        temp.MELCOW[prev_key] = await app.send_photo(
            chat_id,
            photo=welcome_image,
            caption=caption,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        f"🎵 {sc('ᴋɪᴅɴᴀᴘ ᴍᴇ ʙᴀʙʏ')} 🎵",
                        url=f"https://t.me/{app.username}?startgroup=true",
                    )
                ]
            ]),
        )

    except Exception as e:
        LOGGER.error(f"Welcome send error: {e}")

    # ── Cleanup temp files ───────────────────
    for path in (
        f"downloads/welcome_{user.id}.png",
        f"downloads/pp{user.id}.png",
    ):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass