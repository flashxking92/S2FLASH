# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: Maharashtra Aurangabad
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦

import asyncio
import re
from time import time
from datetime import datetime
from pyrogram import filters, types, enums
from ZarkoMusicBot import app

user_last_message_time = {}
user_command_count = {}
SPAM_THRESHOLD = 2
SPAM_WINDOW_SECONDS = 5

async def userstatus(user_id):
    try:
        user = await app.get_users(user_id)
        status = user.status
        if status == enums.UserStatus.RECENTLY:
            return "ʀᴇᴄᴇɴᴛʟʏ ᴀᴄᴛɪᴠᴇ"
        elif status == enums.UserStatus.LAST_WEEK:
            return "ʟᴀsᴛ ᴡᴇᴇᴋ"
        elif status == enums.UserStatus.LONG_AGO:
            return "ʟᴏɴɢ ᴛɪᴍᴇ ᴀɢᴏ"
        elif status == enums.UserStatus.OFFLINE:
            return "ᴏғғʟɪɴᴇ"
        elif status == enums.UserStatus.ONLINE:
            return "ᴏɴʟɪɴᴇ ɴᴏᴡ"
        else:
            return "ᴜɴᴋɴᴏᴡɴ"
    except:
        return "ᴜɴᴋɴᴏᴡɴ"

INFO_CAPTION = """
<b>👤 ᴜsᴇʀ ɪɴғᴏʀᴍᴀᴛɪᴏɴ</b>

<b>🆔 ɪᴅ:</b> <code>{}</code>
<b>👨‍💻 ɴᴀᴍᴇ:</b> {}
<b>🏷 ᴜsᴇʀɴᴀᴍᴇ:</b> {}
<b>🔗 ᴍᴇɴᴛɪᴏɴ:</b> {}
<b>📡 ᴅᴄ ɪᴅ:</b> {}
<b>💎 ᴘʀᴇᴍɪᴜᴍ:</b> {}
<b>💬 ʙɪᴏ:</b> {}
<b>👥 ᴍᴜᴛᴜᴀʟ ɢʀᴏᴜᴘs:</b> {}
<b>📅 ᴊᴏɪɴᴇᴅ:</b> {}
<b>📶 sᴛᴀᴛᴜs:</b> {}
"""

@app.on_message(filters.command(["info", "userinfo"], prefixes=["/", "!", "%", ",", ".", "@", "#"]))
async def userinfo(_, message):
    user_id = message.from_user.id
    current_time = time()

    last_message_time = user_last_message_time.get(user_id, 0)
    if current_time - last_message_time < SPAM_WINDOW_SECONDS:
        user_command_count[user_id] = user_command_count.get(user_id, 0) + 1
        if user_command_count[user_id] > SPAM_THRESHOLD:
            warn = await message.reply_text(
                f"⚠️ {message.from_user.mention}, ᴅᴏɴ'ᴛ sᴘᴀᴍ. ᴛʀʏ ᴀɢᴀɪɴ ᴀғᴛᴇʀ ᴀ ᴍᴏᴍᴇɴᴛ."
            )
            await asyncio.sleep(3)
            return await warn.delete()
    else:
        user_command_count[user_id] = 1
        user_last_message_time[user_id] = current_time

    if message.reply_to_message:
        target = message.reply_to_message.from_user
    elif len(message.command) > 1:
        try:
            target = await app.get_users(message.text.split(None, 1)[1])
        except Exception as e:
            return await message.reply_text(f"⚠️ {e}")
    else:
        target = message.from_user

    try:
        user_info = await app.get_chat(target.id)
        status = await userstatus(target.id)

        user_id = target.id
        name = f"{user_info.first_name or ''} {user_info.last_name or ''}".strip() or "ɴᴏ ɴᴀᴍᴇ"
        username = f"@{user_info.username}" if user_info.username else "ɴᴏ ᴜsᴇʀɴᴀᴍᴇ"
        mention = target.mention
        dc_id = getattr(target, "dc_id", "ᴜɴᴋɴᴏᴡɴ")
        premium = "✅ ʏᴇs" if getattr(target, "is_premium", False) else "❌ ɴᴏ"

        bio_raw = user_info.bio or ""
        if not bio_raw:
            bio = "ɴᴏ ʙɪᴏ sᴇᴛ"
        elif re.search(r"(t\.me|https?://|@)", bio_raw, re.IGNORECASE):
            if "@" in bio_raw:
                bio = "ᴜsᴇʀ ʜᴀs ᴀ ᴜsᴇʀɴᴀᴍᴇ ɪɴ ʙɪᴏ 🪄"
            else:
                bio = "ᴜsᴇʀ ʜᴀs ᴀ ʟɪɴᴋ ɪɴ ʙɪᴏ 🌐"
        else:
            bio = bio_raw

        try:
            mutual_chats = await app.get_common_chats(target.id)
            mutual_count = len(mutual_chats)
        except:
            mutual_count = "ᴜɴᴀᴠᴀɪʟᴀʙʟᴇ"

        join_date = getattr(target, "added_to_attachment_menu_date", None)
        join_str = join_date.strftime("%d %b %Y") if join_date else "ᴜɴᴀᴠᴀɪʟᴀʙʟᴇ"

        caption = INFO_CAPTION.format(
            user_id, name, username, mention, dc_id, premium, bio, mutual_count, join_str, status
        )

        btn = [
            [
                types.InlineKeyboardButton(
                    "🌐 ᴠɪᴇᴡ ᴘʀᴏғɪʟᴇ",
                    url=f"https://t.me/{target.username}" if target.username else "https://t.me/",
                )
            ]
        ]

        await message.reply_text(
            caption,
            reply_markup=types.InlineKeyboardMarkup(btn),
            disable_web_page_preview=True,
        )

    except Exception as e:
        await message.reply_text(f"⚠️ ᴇʀʀᴏʀ: {e}")

__MODULE__ = "Usᴇʀ ɪɴғᴏ"
__HELP__ = """
/ɪɴғᴏ [ᴜsᴇʀ_ɪᴅ] - sʜᴏᴡ ᴜsᴇʀ ɪɴғᴏʀᴍᴀᴛɪᴏɴ 💫  
/ᴜsᴇʀɪɴғᴏ [ᴜsᴇʀ_ɪᴅ] - sᴀᴍᴇ ᴀs /ɪɴғᴏ
"""
