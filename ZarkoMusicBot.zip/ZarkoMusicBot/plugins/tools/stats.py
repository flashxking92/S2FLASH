# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: Maharashtra Aurangabad
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦


import platform
from sys import version as pyver

import psutil
from pyrogram import __version__ as pyrover
from pyrogram import filters
from pyrogram.errors import MessageIdInvalid
from pyrogram.types import InputMediaPhoto, Message
from pytgcalls.__version__ import __version__ as pytgver

import config
from ZarkoMusicBot import app
from ZarkoMusicBot.core.userbot import assistants
from ZarkoMusicBot.misc import SUDOERS, mongodb
from ZarkoMusicBot.plugins import ALL_MODULES
from ZarkoMusicBot.utils.database import get_served_chats, get_served_users, get_sudoers,is_autoend,is_autoleave
from ZarkoMusicBot.utils.decorators.language import language, languageCB
from ZarkoMusicBot.utils.inline.stats import back_stats_buttons, stats_buttons
from config import BANNED_USERS


@app.on_message(filters.command(["stats", "gstats"]) & filters.group & ~BANNED_USERS)
@language
async def stats_global(client, message: Message, _):
    upl = stats_buttons(_, True if message.from_user.id in SUDOERS else False)
    await message.reply_photo(
        photo=config.STATS_IMG_URL,
        caption=_["gstats_2"].format(app.mention),
        reply_markup=upl,
    )


@app.on_callback_query(filters.regex("stats_back") & ~BANNED_USERS)
@languageCB
async def home_stats(client, CallbackQuery, _):
    upl = stats_buttons(_, True if CallbackQuery.from_user.id in SUDOERS else False)
    await CallbackQuery.edit_message_text(
        text=_["gstats_2"].format(app.mention),
        reply_markup=upl,
    )


@app.on_callback_query(filters.regex("TopOverall") & ~BANNED_USERS)
@languageCB
async def overall_stats(client, CallbackQuery, _):
    await CallbackQuery.answer()
    upl = back_stats_buttons(_)
    try:
        await CallbackQuery.answer()
    except:
        pass
    await CallbackQuery.edit_message_text(_["gstats_1"].format(app.mention))
    served_chats = len(await get_served_chats())
    served_users = len(await get_served_users())
    text = _["gstats_3"].format(
        app.mention,
        len(assistants),
        len(BANNED_USERS),
        served_chats,
        served_users,
        len(ALL_MODULES),
        len(SUDOERS),
        await is_autoend(),
        config.DURATION_LIMIT_MIN,
        await is_autoleave()  
    )
    med = InputMediaPhoto(media=config.STATS_IMG_URL, caption=text)
    try:
        await CallbackQuery.edit_message_media(media=med, reply_markup=upl)
    except MessageIdInvalid:
        await CallbackQuery.message.reply_photo(
            photo=config.STATS_IMG_URL, caption=text, reply_markup=upl
        )


@app.on_callback_query(filters.regex("bot_stats_sudo"))
@languageCB
async def bot_stats(client, CallbackQuery, _):
    if CallbackQuery.from_user.id not in SUDOERS:
        return await CallbackQuery.answer(_["gstats_4"], show_alert=True)
    upl = back_stats_buttons(_)
    try:
        await CallbackQuery.answer()
    except:
        pass
    await CallbackQuery.edit_message_text(_["gstats_1"].format(app.mention))
    p_core = psutil.cpu_count(logical=False)
    t_core = psutil.cpu_count(logical=True)
    ram = str(round(psutil.virtual_memory().total / (1024.0**3))) + " ɢʙ"
    try:
        cpu_freq = psutil.cpu_freq().current
        if cpu_freq >= 1000:
            cpu_freq = f"{round(cpu_freq / 1000, 2)}ɢʜᴢ"
        else:
            cpu_freq = f"{round(cpu_freq, 2)}ᴍʜᴢ"
    except:
        cpu_freq = "ғᴀɪʟᴇᴅ ᴛᴏ ғᴇᴛᴄʜ"
    hdd = psutil.disk_usage("/")
    total = hdd.total / (1024.0**3)
    used = hdd.used / (1024.0**3)
    free = hdd.free / (1024.0**3)
    call = await mongodb.command("dbstats")
    datasize = call["dataSize"] / 1024
    storage = call["storageSize"] / 1024
    served_chats = len(await get_served_chats())
    served_users = len(await get_served_users())
    text = _["gstats_5"].format(
        app.mention,
        len(ALL_MODULES),
        platform.system(),
        ram,
        p_core,
        t_core,
        cpu_freq,
        pyver.split()[0],
        pyrover,
        pytgver,
        str(total)[:4],
        str(used)[:4],
        str(free)[:4],
        served_chats,
        served_users,
        len(BANNED_USERS),
        len(await get_sudoers()),
        str(datasize)[:6],
        storage,
        call["collections"],
        call["objects"],
    )
    med = InputMediaPhoto(media=config.STATS_IMG_URL, caption=text)
    try:
        await CallbackQuery.edit_message_media(media=med, reply_markup=upl)
    except MessageIdInvalid:
        await CallbackQuery.message.reply_photo(
            photo=config.STATS_IMG_URL, caption=text, reply_markup=upl
        )


# ═══════════════════════════════════════════════════════════
# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝐑𝐞𝐬𝐞𝐫𝐯𝐞𝐝 - @𝐖𝐡𝐲_𝐍𝐨𝐓_𝐙𝐚𝐫𝐤𝐨 - ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚
# ═══════════════════════════════════════════════════════════
# ©️ 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ (@𝐖𝐡𝐘_𝐍𝐨𝐓_𝐙𝐚𝐫𝐊𝐨)
# 🔗 𝐆𝐢𝐭𝐇𝐮𝐛 : 𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# 📢 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 : 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════
# ❤️ 𝐋𝐨𝐯𝐞 𝐅𝐫𝐨𝐦 𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════ 
