# ═══════════════════════════════════════════════════════════════════════
# ꜰʟᴀꜱʜ ᴀᴜᴛᴏ-ʟᴇᴀᴠᴇ & ᴀᴜᴛᴏ-ᴇɴᴅ ᴍᴏᴅᴜʟᴇ
# ═══════════════════════════════════════════════════════════════════════
# © 2026 ࿐𓆩⚚ ʷʰʸ ᶰᵒᵗ 𝒁𝑨𝑹𝑲𝑶 ⚚—͟͟͞͞𓆪࿐ <@WhY_NoT_ZarKo>
# ⚠️ ᴅᴏ ɴᴏᴛ ᴄᴏᴘʏ / ʀᴇᴅɪꜱᴛʀɪʙᴜᴛᴇ
# ═══════════════════════════════════════════════════════════════════════

import asyncio
import logging

from pyrogram.enums import ChatType

# ─────────────────────────────
# Safe Import Fix (PyTgCalls)
# ─────────────────────────────
try:
    from pytgcalls.exceptions import GroupCallNotFound
except Exception:
    try:
        from pytgcalls.exceptions import NoActiveGroupCall as GroupCallNotFound
    except Exception:
        GroupCallNotFound = Exception

import config

from ZarkoMusicBot import app
from ZarkoMusicBot.misc import db
from ZarkoMusicBot.core.call import Nand, autoend
from ZarkoMusicBot.core.userbot import assistants
from ZarkoMusicBot.utils.database import (
    get_client,
    set_loop,
    is_active_chat,
    is_autoend,
    is_autoleave,
)

# ─────────────────────────────
# Logging Setup
# ─────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [ꜰʟᴀꜱʜ] - %(levelname)s - %(message)s",
)

LOGGER = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# ꜰʟᴀꜱʜ ᴀᴜᴛᴏ-ʟᴇᴀᴠᴇ ꜱʏꜱᴛᴇᴍ
# ─────────────────────────────────────────────
# • ʟᴇᴀᴠᴇꜱ ɪɴᴀᴄᴛɪᴠᴇ ᴄʜᴀᴛꜱ
# • ꜱᴋɪᴘꜱ ʟᴏɢ ɢʀᴏᴜᴘ
# • ꜱᴀꜰᴇ & ꜱᴛᴀʙʟᴇ
# ─────────────────────────────────────────────

async def auto_leave():
    await asyncio.sleep(10)

    while True:
        try:
            # 12 hours wait
            await asyncio.sleep(43200)

            # feature disabled
            if not await is_autoleave():
                continue

            for num in assistants:
                try:
                    client = await get_client(num)
                    left = 0

                    async for dialog in client.get_dialogs():
                        try:
                            chat = dialog.chat

                            if not chat:
                                continue

                            # only groups/channels
                            if chat.type not in (
                                ChatType.SUPERGROUP,
                                ChatType.GROUP,
                                ChatType.CHANNEL,
                            ):
                                continue

                            # skip log group
                            if chat.id == config.LOG_GROUP_ID:
                                continue

                            # limit leave count
                            if left >= 20:
                                break

                            # leave inactive chats
                            if not await is_active_chat(chat.id):

                                await client.leave_chat(chat.id)
                                left += 1

                                LOGGER.info(
                                    f"ꜰʟᴀꜱʜ ➠ ʟᴇꜰᴛ ɪɴᴀᴄᴛɪᴠᴇ ᴄʜᴀᴛ → {chat.id}"
                                )

                                # anti-flood protection
                                await asyncio.sleep(1)

                        except Exception as e:
                            LOGGER.warning(
                                f"ꜰʟᴀꜱʜ ➠ ʟᴇᴀᴠᴇ ꜰᴀɪʟᴇᴅ → "
                                f"{getattr(chat, 'id', '?')} : {e}"
                            )

                except Exception as e:
                    LOGGER.error(
                        f"ꜰʟᴀꜱʜ ➠ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴇʀʀᴏʀ → {e}"
                    )

        except Exception as e:
            LOGGER.error(
                f"ꜰʟᴀꜱʜ ➠ ᴀᴜᴛᴏ-ʟᴇᴀᴠᴇ ꜰᴀᴛᴀʟ → {e}"
            )

            await asyncio.sleep(10)


# ─────────────────────────────
# AUTO END (EVERY 60 SEC)
# ─────────────────────────────
async def auto_end():
    await asyncio.sleep(10)

    while True:
        try:
            await asyncio.sleep(60)

            # feature disabled
            if not await is_autoend():
                continue

            chats = list(autoend.keys())

            for chat_id in chats:
                try:
                    try:
                        users = len(await Nand.get_participants(chat_id))
                        nocall = False

                    except GroupCallNotFound:
                        users = 1
                        nocall = True

                    except Exception:
                        users = 100
                        nocall = False

                    # if listeners exist
                    if users != 1:
                        continue

                    # cleanup loop
                    await set_loop(chat_id, 0)

                    # delete player message
                    try:
                        await db[chat_id][0]["mystic"].delete()
                    except Exception:
                        pass

                    # stop stream
                    try:
                        await Nand.stop_stream(chat_id)
                    except Exception:
                        pass

                    # send auto-end message
                    if not nocall:
                        try:
                            await app.send_message(
                                chat_id,
                                "» ɴᴏ ʟɪꜱᴛᴇɴᴇʀꜱ → ᴀᴜᴛᴏ ʟᴇꜰᴛ ᴠᴄ.",
                            )
                        except Exception:
                            pass

                    # remove from autoend
                    autoend.pop(chat_id, None)

                    LOGGER.info(f"ᴀᴜᴛᴏ-ᴇɴᴅ → {chat_id}")

                except Exception as e:
                    LOGGER.warning(
                        f"ᴀᴜᴛᴏ-ᴇɴᴅ ᴇʀʀᴏʀ → {chat_id} : {e}"
                    )

        except Exception as e:
            LOGGER.error(f"ᴀᴜᴛᴏ-ᴇɴᴅ ꜰᴀᴛᴀʟ → {e}")

            await asyncio.sleep(10)


# ─────────────────────────────
# START TASKS SAFELY
# ─────────────────────────────
async def start_autotasks():
    asyncio.create_task(auto_leave())
    asyncio.create_task(auto_end())