# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: Maharashtra Aurangabad
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦


from pyrogram import filters
from pyrogram.types import Message

from ZarkoMusicBot import app
from ZarkoMusicBot.core.call import Nand
from ZarkoMusicBot.misc import SUDOERS, db
from ZarkoMusicBot.utils import AdminRightsCheck
from ZarkoMusicBot.utils.database import is_active_chat, is_nonadmin_chat
from ZarkoMusicBot.utils.decorators.language import languageCB
from ZarkoMusicBot.utils.inline import close_markup, speed_markup
from config import BANNED_USERS, adminlist

checker = []


@app.on_message(
    filters.command(["cspeed", "speed", "cslow", "slow", "playback", "cplayback"])
    & filters.group
    & ~BANNED_USERS
)
@AdminRightsCheck
async def playback(cli, message: Message, _, chat_id):
    playing = db.get(chat_id)
    if not playing:
        return await message.reply_text(_["queue_2"])
    duration_seconds = int(playing[0]["seconds"])
    if duration_seconds == 0:
        return await message.reply_text(_["admin_27"])
    file_path = playing[0]["file"]
    if "downloads" not in file_path:
        return await message.reply_text(_["admin_27"])
    upl = speed_markup(_, chat_id)
    return await message.reply_text(
        text=_["admin_28"].format(app.mention),
        reply_markup=upl,
    )


@app.on_callback_query(filters.regex("SpeedUP") & ~BANNED_USERS)
@languageCB
async def del_back_playlist(client, CallbackQuery, _):
    callback_data = CallbackQuery.data.strip()
    callback_request = callback_data.split(None, 1)[1]
    chat, speed = callback_request.split("|")
    chat_id = int(chat)
    if not await is_active_chat(chat_id):
        return await CallbackQuery.answer(_["general_5"], show_alert=True)
    is_non_admin = await is_nonadmin_chat(CallbackQuery.message.chat.id)
    if not is_non_admin:
        if CallbackQuery.from_user.id not in SUDOERS:
            admins = adminlist.get(CallbackQuery.message.chat.id)
            if not admins:
                return await CallbackQuery.answer(_["admin_13"], show_alert=True)
            else:
                if CallbackQuery.from_user.id not in admins:
                    return await CallbackQuery.answer(_["admin_14"], show_alert=True)
    playing = db.get(chat_id)
    if not playing:
        return await CallbackQuery.answer(_["queue_2"], show_alert=True)
    duration_seconds = int(playing[0]["seconds"])
    if duration_seconds == 0:
        return await CallbackQuery.answer(_["admin_27"], show_alert=True)
    file_path = playing[0]["file"]
    if "downloads" not in file_path:
        return await CallbackQuery.answer(_["admin_27"], show_alert=True)
    checkspeed = (playing[0]).get("speed")
    if checkspeed:
        if str(checkspeed) == str(speed):
            if str(speed) == str("1.0"):
                return await CallbackQuery.answer(
                    _["admin_29"],
                    show_alert=True,
                )
    else:
        if str(speed) == str("1.0"):
            return await CallbackQuery.answer(
                _["admin_29"],
                show_alert=True,
            )
    if chat_id in checker:
        return await CallbackQuery.answer(
            _["admin_30"],
            show_alert=True,
        )
    else:
        checker.append(chat_id)
    try:
        await CallbackQuery.answer(
            _["admin_31"],
        )
    except:
        pass
    mystic = await CallbackQuery.edit_message_text(
        text=_["admin_32"].format(CallbackQuery.from_user.mention),
    )
    try:
        await Nand.speedup_stream(
            chat_id,
            file_path,
            speed,
            playing,
        )
    except:
        if chat_id in checker:
            checker.remove(chat_id)
        return await mystic.edit_text(_["admin_33"], reply_markup=close_markup(_))
    if chat_id in checker:
        checker.remove(chat_id)
    await mystic.edit_text(
        text=_["admin_34"].format(speed, CallbackQuery.from_user.mention),
        reply_markup=close_markup(_),
    )


# ═══════════════════════════════════════════════════════════
# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝐑𝐞𝐬𝐞𝐫𝐯𝐞𝐝 - @𝐖𝐡𝐲_𝐍𝐨𝐓_𝐙𝐚𝐫𝐤𝐨 - ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚
# ═══════════════════════════════════════════════════════════
# ©️ 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ (@𝐖𝐡𝐘_𝐍𝐨𝐓_𝐙𝐚𝐫𝐊𝐨)
# 🔗 𝐆𝐢𝐭𝐇𝐮𝐛 : 𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# 📢 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 : 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════
# ❤️ 𝐋𝐨𝐯𝐞 𝐅𝐫𝐨𝐦 𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════ 
