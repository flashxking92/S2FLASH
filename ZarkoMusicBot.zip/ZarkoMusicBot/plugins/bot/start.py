import time
import asyncio
import random
from pyrogram import filters
from pyrogram.enums import ChatType
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from py_yt import VideosSearch
import config
from ZarkoMusicBot import app
from ZarkoMusicBot.misc import _boot_
from ZarkoMusicBot.plugins.sudo.sudoers import sudoers_list
from ZarkoMusicBot.utils.database import (
    add_served_chat,
    add_served_user,
    blacklisted_chats,
    get_lang,
    is_banned_user,
    is_on_off,
)
from ZarkoMusicBot.utils import bot_sys_stats
from ZarkoMusicBot.utils.decorators.language import LanguageStart
from ZarkoMusicBot.utils.formatters import get_readable_time
from ZarkoMusicBot.utils.inline import help_pannel_page1, private_panel, start_panel
from config import BANNED_USERS
from strings import get_string

# Valid sticker IDs (all working stickers)
STICKERS = [
    "CAACAgUAAxkBAAEQI1RlTLnRAy4h9lOS6jgS5FYsQoruOAAC1gMAAg6ryVcldUr_lhPexzME",
    "CAACAgQAAxkBAAMraaaBHm27-Wy2uQoptU3WZAAB6j3PAALEFQACIPCZUR1h3KoW6nItHgQ",
    "CAACAgQAAxkBAAMtaaaBKyjqLW8aBukB-vtOy-pUCxwAAoIOAAIF9AFSd_QCdbkZVqAeBA",
    "CAACAgQAAxkBAAMvaaaBNyAKbOtk05em_J8gQTmqotsAAhELAAIbGgABUuUNZ1V7LfMMHgQ",
    "CAACAgQAAxkBAAMxaaaBTZjH9A31Qdrb_xgKnrd4700AArgaAAJLO-hR8MN1DY1xe2ceBA",
    "CAACAgQAAxkBAAMzaaaBUYNDr2RENDvdHTkz5tg-lVcAAmkaAAIIeUlRllAUMDa5YOoeBA",
    "CAACAgQAAxkBAAM5aaaB7A7JfXbtkO7b8ubX6_IjDdIAAhoVAAKRIKFRpathP0j9IIYeBA",
    "CAACAgQAAxkBAAM7aaaB-elXM9UEYY4OIo4eTCIbgigAAuUVAALryRlQRN37BBGYPgYeBA",
    "CAACAgQAAxkBAAM_aaaCCjmuL6EkqSBKpYbYzK3xKCcAAqYTAAK9jHlQ6vzt6mbH8-ceBA",
]

# Valid reaction emojis (Telegram supported)
REACTIONS = ["❤️", "🔥", "🥳", "🎉", "✨", "⭐️", "💋", "🎵", "🎶", "💝", "💖", "💗", "💓", "💞", "💕", "😍", "🤩", "🥰", "😘", "👍", "👌", "👏", "🙌", "🎊", "🎈", "🎁", "💎", "👑"]

async def delete_message_after_delay(message: Message, delay: int):
    """Delete message after specified delay"""
    await asyncio.sleep(delay)
    try:
        await message.delete()
    except:
        pass


@app.on_message(filters.command(["start"]) & filters.private & ~BANNED_USERS)
@LanguageStart
async def start_pm(client, message: Message, _):
    await add_served_user(message.from_user.id)
    
    # Random reaction on start
    try:
        await message.react(random.choice(REACTIONS))
    except:
        try:
            await message.react("❤️")
        except:
            pass
    
    if len(message.text.split()) > 1:
        name = message.text.split(None, 1)[1]
        
        if name[0:4] == "help":
            keyboard = help_pannel_page1(_)
            # Random sticker for help command
            try:
                await message.reply_sticker(random.choice(STICKERS))
            except:
                pass
            try:
                return await message.reply_photo(
                    photo=config.START_IMG_URL,
                    caption=_["help_1"].format(config.SUPPORT_GROUP),
                    reply_markup=keyboard,
                    message_effect_id=5159385139981059251,
                )
            except:
                return await message.reply_photo(
                    photo=config.START_IMG_URL,
                    caption=_["help_1"].format(config.SUPPORT_GROUP),
                    reply_markup=keyboard,
                )
                
        if name[0:3] == "sud":
            await sudoers_list(client=client, message=message, _=_)
            if await is_on_off(2):
                return await app.send_message(
                    chat_id=config.LOG_GROUP_ID,
                    text=f"{message.from_user.mention} ᴊᴜsᴛ sᴛᴀʀᴛᴇᴅ ᴛʜᴇ ʙᴏᴛ ᴛᴏ ᴄʜᴇᴄᴋ <b>sᴜᴅᴏʟɪsᴛ</b>.\n\n<b>ᴜsᴇʀ ɪᴅ :</b> <code>{message.from_user.id}</code>\n<b>ᴜsᴇʀɴᴀᴍᴇ :</b> @{message.from_user.username}",
                )
            return
            
        if name[0:3] == "inf":
            m = await message.reply_text("🔎")
            query = (str(name)).replace("info_", "", 1)
            query = f"https://www.youtube.com/watch?v={query}"
            results = VideosSearch(query, limit=1)
            for result in (await results.next())["result"]:
                title = result["title"]
                duration = result["duration"]
                views = result["viewCount"]["short"]
                thumbnail = result["thumbnails"][0]["url"].split("?")[0]
                channellink = result["channel"]["link"]
                channel = result["channel"]["name"]
                link = result["link"]
                published = result["publishedTime"]
            searched_text = _["start_6"].format(
                title, duration, views, published, channellink, channel, app.mention
            )
            key = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text=_["S_B_8"], url=link),
                        InlineKeyboardButton(text=_["S_B_9"], url=config.SUPPORT_GROUP),
                    ],
                ]
            )
            await m.delete()
            try:
                await app.send_photo(
                    chat_id=message.chat.id,
                    photo=thumbnail,
                    caption=searched_text,
                    reply_markup=key,
                    message_effect_id=5159385139981059251,
                )
            except:
                await app.send_photo(
                    chat_id=message.chat.id,
                    photo=thumbnail,
                    caption=searched_text,
                    reply_markup=key,
                )
            if await is_on_off(2):
                return await app.send_message(
                    chat_id=config.LOG_GROUP_ID,
                    text=f"{message.from_user.mention} ᴊᴜsᴛ sᴛᴀʀᴛᴇᴅ ᴛʜᴇ ʙᴏᴛ ᴛᴏ ᴄʜᴇᴄᴋ <b>ᴛʀᴀᴄᴋ ɪɴғᴏʀᴍᴀᴛɪᴏɴ</b>.\n\n<b>ᴜsᴇʀ ɪᴅ :</b> <code>{message.from_user.id}</code>\n<b>ᴜsᴇʀɴᴀᴍᴇ :</b> @{message.from_user.username}",
                )
                
        if name == "start":
            out = private_panel(_)
            UP, CPU, RAM, DISK = await bot_sys_stats()
            
            # Random sticker
            try:
                sticker_msg = await message.reply_sticker(random.choice(STICKERS))
                asyncio.create_task(delete_message_after_delay(sticker_msg, 3))
            except:
                pass
            
            try:
                await message.reply_photo(
                    photo=config.START_IMG_URL,
                    caption=_["start_2"].format(message.from_user.mention, app.mention, UP, DISK, CPU, RAM),
                    reply_markup=InlineKeyboardMarkup(out),
                    message_effect_id=5159385139981059251,
                )
            except:
                await message.reply_photo(
                    photo=config.START_IMG_URL,
                    caption=_["start_2"].format(message.from_user.mention, app.mention, UP, DISK, CPU, RAM),
                    reply_markup=InlineKeyboardMarkup(out),
                )
            if await is_on_off(2):
                return await app.send_message(
                    chat_id=config.LOG_GROUP_ID,
                    text=f"{message.from_user.mention} ᴊᴜsᴛ sᴛᴀʀᴛᴇᴅ ᴛʜᴇ ʙᴏᴛ.\n\n<b>ᴜsᴇʀ ɪᴅ :</b> <code>{message.from_user.id}</code>\n<b>ᴜsᴇʀɴᴀᴍᴇ :</b> @{message.from_user.username}",
                )
    else:
        # Animation for normal start (no args)
        try:
            # Welcome animation
            welcome_msgs = [
                "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐁𝐚𝐛𝐲 ꨄ︎ {}.. ❣️",
                "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐁𝐚𝐛𝐲 ꨄ {}.. 🥳",
                "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐁𝐚𝐛𝐲 ꨄ {}.. 💥",
                "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐁𝐚𝐛𝐲 ꨄ {}.. 🤩",
                "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐁𝐚𝐛𝐲 ꨄ {}.. 💌",
                "𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐁𝐚𝐛𝐲 ꨄ {}.. 💞",
            ]
            
            lol = await message.reply_text(welcome_msgs[0].format(message.from_user.mention))
            for msg in welcome_msgs[1:]:
                await asyncio.sleep(0.3)
                await lol.edit_text(msg.format(message.from_user.mention))
            await lol.delete()
            
            # Starting animation
            start_msgs = [
                "**⚡️ѕ**",
                "⚡ѕт",        
                "**⚡ѕтα**",
                "**⚡ѕтαя**",
                "**⚡ѕтαят**",
                "**⚡ѕтαятι**",
                "**⚡ѕтαятιи**",
                "**⚡ѕтαятιиg**",
                "**⚡ѕтαятιиg.**",
                "**⚡ѕтαятιиg....**",
                "**⚡ѕтαятιиg.**",
                "**⚡ѕтαятιиg....**",
            ]
            
            lols = await message.reply_text(start_msgs[0])
            for msg in start_msgs[1:]:
                await asyncio.sleep(0.1)
                await lols.edit_text(msg)
            await lols.delete()
            
            # Random sticker
            try:
                sticker_msg = await message.reply_sticker(random.choice(STICKERS))
                asyncio.create_task(delete_message_after_delay(sticker_msg, 3))
            except:
                pass
            
            # Get user photo
            if message.from_user.photo:
                userss_photo = await app.download_media(message.from_user.photo.big_file_id)
            else:
                userss_photo = "assets/nodp.png"
                
        except Exception as e:
            print(f"Animation error: {e}")
            userss_photo = "assets/nodp.png"
        
        out = private_panel(_)
        UP, CPU, RAM, DISK = await bot_sys_stats()
        
        # Use user photo if available, otherwise default
        chat_photo = userss_photo if userss_photo != "assets/nodp.png" else config.START_IMG_URL
        
        try:
            await message.reply_photo(
                photo=chat_photo,
                caption=_["start_2"].format(message.from_user.mention, app.mention, UP, DISK, CPU, RAM),
                reply_markup=InlineKeyboardMarkup(out),
                message_effect_id=5159385139981059251,
            )
        except:
            await message.reply_photo(
                photo=chat_photo,
                caption=_["start_2"].format(message.from_user.mention, app.mention, UP, DISK, CPU, RAM),
                reply_markup=InlineKeyboardMarkup(out),
            )
            
        if await is_on_off(2):
            return await app.send_message(
                chat_id=config.LOG_GROUP_ID,
                text=f"{message.from_user.mention} ᴊᴜsᴛ sᴛᴀʀᴛᴇᴅ ᴛʜᴇ ʙᴏᴛ.\n\n<b>ᴜsᴇʀ ɪᴅ :</b> <code>{message.from_user.id}</code>\n<b>ᴜsᴇʀɴᴀᴍᴇ :</b> @{message.from_user.username}",
            )


@app.on_message(filters.command(["start"]) & filters.group & ~BANNED_USERS)
@LanguageStart
async def start_gp(client, message: Message, _):
    # Random reaction for group
    try:
        await message.react(random.choice(REACTIONS))
    except:
        try:
            await message.react("❤️")
        except:
            pass
    
    # Random sticker for group
    try:
        sticker_msg = await message.reply_sticker(random.choice(STICKERS))
        asyncio.create_task(delete_message_after_delay(sticker_msg, 3))
    except:
        pass
    
    out = start_panel(_)
    uptime = int(time.time() - _boot_)
    try:
        await message.reply_photo(
            photo=config.START_IMG_URL,
            caption=_["start_1"].format(app.mention, get_readable_time(uptime)),
            reply_markup=InlineKeyboardMarkup(out),
            message_effect_id=5159385139981059251,
        )
    except:
        await message.reply_photo(
            photo=config.START_IMG_URL,
            caption=_["start_1"].format(app.mention, get_readable_time(uptime)),
            reply_markup=InlineKeyboardMarkup(out),
        )
    return await add_served_chat(message.chat.id)


@app.on_message(filters.new_chat_members, group=-1)
async def welcome(client, message: Message):
    for member in message.new_chat_members:
        try:
            language = await get_lang(message.chat.id)
            _ = get_string(language)
            
            if await is_banned_user(member.id):
                try:
                    await message.chat.ban_member(member.id)
                except:
                    pass
                    
            if member.id == app.id:
                if message.chat.type != ChatType.SUPERGROUP:
                    await message.reply_text(_["start_4"])
                    return await app.leave_chat(message.chat.id)
                    
                if message.chat.id in await blacklisted_chats():
                    await message.reply_text(
                        _["start_5"].format(
                            app.mention,
                            f"https://t.me/{app.username}?start=sudolist",
                            config.SUPPORT_GROUP,
                        ),
                        disable_web_page_preview=True,
                    )
                    return await app.leave_chat(message.chat.id)

                # Random sticker for welcome
                try:
                    await message.reply_sticker(random.choice(STICKERS))
                except:
                    pass

                out = start_panel(_)
                try:
                    await message.reply_photo(
                        photo=config.START_IMG_URL,
                        caption=_["start_3"].format(
                            message.from_user.first_name,
                            app.mention,
                            message.chat.title,
                            app.mention,
                        ),
                        reply_markup=InlineKeyboardMarkup(out),
                        message_effect_id=5159385139981059251,
                    )
                except:
                    await message.reply_photo(
                        photo=config.START_IMG_URL,
                        caption=_["start_3"].format(
                            message.from_user.first_name,
                            app.mention,
                            message.chat.title,
                            app.mention,
                        ),
                        reply_markup=InlineKeyboardMarkup(out),
                    )
                await add_served_chat(message.chat.id)
                await message.stop_propagation()
                
        except Exception as ex:
            print(ex)