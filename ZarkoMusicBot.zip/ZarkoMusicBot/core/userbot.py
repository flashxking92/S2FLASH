# ╔══════════════════════════════════════════════════════════════╗
# ║  ©️ ᴄᴏᴘʏʀɪɢʜᴛ (ᴄ) 2026 ⚚ ᴢᴀʀᴋᴏ ⚚ — @ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ           ║
# ║  📍 ʟᴏᴄᴀᴛɪᴏɴ : ꜱᴜᴘᴀᴜʟ, ʙɪʜᴀʀ                                ║
# ║  ⚖️  ᴀʟʟ ʀɪɢʜᴛꜱ ʀᴇꜱᴇʀᴠᴇᴅ                                    ║
# ╠══════════════════════════════════════════════════════════════╣
# ║  ✅ ᴀʟʟᴏᴡᴇᴅ  :  ꜰᴏʀᴋɪɴɢ ꜰᴏʀ ᴘᴇʀꜱᴏɴᴀʟ ʟᴇᴀʀɴɪɴɢ              ║
# ║                  ꜱᴜʙᴍɪᴛᴛɪɴɢ ɪᴍᴘʀᴏᴠᴇᴍᴇɴᴛꜱ ᴠɪᴀ ᴘʀ             ║
# ║  ❌ ɴᴏᴛ ᴀʟʟᴏᴡᴇᴅ: ᴄʟᴀɪᴍɪɴɢ ᴀꜱ ʏᴏᴜʀ ᴏᴡɴ                      ║
# ║                  ʀᴇ-ᴜᴘʟᴏᴀᴅɪɴɢ ᴡɪᴛʜᴏᴜᴛ ᴄʀᴇᴅɪᴛ                ║
# ║                  ꜱᴇʟʟɪɴɢ ᴏʀ ᴄᴏᴍᴍᴇʀᴄɪᴀʟ ᴜꜱᴇ                  ║
# ║  📧 ᴄᴏɴᴛᴀᴄᴛ    : ᴀʟᴛᴜϙ92@ɢᴍᴀɪʟ.ᴄᴏᴍ                         ║
# ╚══════════════════════════════════════════════════════════════╝

import asyncio
from typing import Optional

import config
from pyrogram import Client

from ..logging import LOGGER

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ɢʟᴏʙᴀʟ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴛʀᴀᴄᴋᴇʀꜱ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ʟɪꜱᴛ ᴏꜰ ᴀᴄᴛɪᴠᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ꜱʟᴏᴛ ɴᴜᴍʙᴇʀꜱ  (ᴇ.ɢ. [1, 3])
assistants: list[int] = []

# ʟɪꜱᴛ ᴏꜰ ᴀᴄᴛɪᴠᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴛᴇʟᴇɢʀᴀᴍ ᴜꜱᴇʀ ɪᴅꜱ
assistantids: list[int] = []


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ʜᴇʟᴘᴇʀ — ʙᴜɪʟᴅ ᴀ ꜱɪɴɢʟᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴄʟɪᴇɴᴛ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _make_client(name: str, session_string: str) -> Client:
    """ʀᴇᴛᴜʀɴꜱ ᴀ ᴄᴏɴꜰɪɢᴜʀᴇᴅ ᴘʏʀᴏɢʀᴀᴍ ᴄʟɪᴇɴᴛ ꜰᴏʀ ᴀɴ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴀᴄᴄᴏᴜɴᴛ."""
    return Client(
        name=name,
        api_id=config.API_ID,
        api_hash=config.API_HASH,
        session_string=session_string,
        no_updates=True,
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ᴜꜱᴇʀʙᴏᴛ ᴄʟᴀꜱꜱ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class Userbot:
    """
    ᴍᴀɴᴀɢᴇꜱ ᴜᴘ ᴛᴏ 5 ᴘʏʀᴏɢʀᴀᴍ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴀᴄᴄᴏᴜɴᴛꜱ.

    ᴇᴀᴄʜ ꜱʟᴏᴛ (ᴏɴᴇ … ꜰɪᴠᴇ) ɪꜱ ᴏɴʟʏ ɪɴɪᴛɪᴀʟɪᴢᴇᴅ ᴡʜᴇɴ ɪᴛꜱ
    ᴄᴏʀʀᴇꜱᴘᴏɴᴅɪɴɢ STRING_SESSION ɪꜱ ꜱᴇᴛ ɪɴ ᴄᴏɴꜰɪɢ.
    """

    def __init__(self):
        # ꜱʟᴏᴛ 1
        self.one: Optional[Client] = (
            _make_client("ZarkoAss1", str(config.STRING1))
            if config.STRING1 else None
        )
        # ꜱʟᴏᴛ 2
        self.two: Optional[Client] = (
            _make_client("ZarkoAss2", str(config.STRING2))
            if config.STRING2 else None
        )
        # ꜱʟᴏᴛ 3
        self.three: Optional[Client] = (
            _make_client("ZarkoAss3", str(config.STRING3))
            if config.STRING3 else None
        )
        # ꜱʟᴏᴛ 4
        self.four: Optional[Client] = (
            _make_client("ZarkoAss4", str(config.STRING4))
            if config.STRING4 else None
        )
        # ꜱʟᴏᴛ 5
        self.five: Optional[Client] = (
            _make_client("ZarkoAss5", str(config.STRING5))
            if config.STRING5 else None
        )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    #  ɪɴᴛᴇʀɴᴀʟ ʜᴇʟᴘᴇʀ — ꜱᴛᴀʀᴛ ᴏɴᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ꜱʟᴏᴛ
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def _start_assistant(
        self,
        client: Client,
        slot: int,
    ) -> bool:
        """
        ꜱᴛᴀʀᴛꜱ ᴀ ꜱɪɴɢʟᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ, ᴠᴇʀɪꜰɪᴇꜱ ʟᴏɢ-ɢʀᴏᴜᴘ ᴀᴄᴄᴇꜱꜱ,
        ᴀɴᴅ ʀᴇɢɪꜱᴛᴇʀꜱ ɪᴛ ɪɴ ɢʟᴏʙᴀʟ ᴛʀᴀᴄᴋᴇʀꜱ.
        ʀᴇᴛᴜʀɴꜱ Tʀᴜᴇ ᴏɴ ꜱᴜᴄᴄᴇꜱꜱ, Fᴀʟꜱᴇ ᴏɴ ꜰᴀɪʟᴜʀᴇ.
        """
        try:
            await client.start()
        except Exception as e:
            LOGGER(__name__).error(
                f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} — ꜰᴀɪʟᴇᴅ ᴛᴏ ꜱᴛᴀʀᴛ ꜱᴇꜱꜱɪᴏɴ : {e}"
            )
            return False

        # ᴄʜᴇᴄᴋ ʟᴏɢ ɢʀᴏᴜᴘ ᴀᴄᴄᴇꜱꜱ
        try:
            await client.send_message(
                config.LOG_GROUP_ID,
                f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} ꜱᴛᴀʀᴛᴇᴅ ✅",
            )
        except Exception as e:
            LOGGER(__name__).error(
                f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} — ᴄᴀɴɴᴏᴛ ᴀᴄᴄᴇꜱꜱ ʟᴏɢ ɢʀᴏᴜᴘ!\n"
                f"   ➤ ᴍᴀᴋᴇ ꜱᴜʀᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ɪꜱ ᴀᴅᴅᴇᴅ ᴀɴᴅ ᴘʀᴏᴍᴏᴛᴇᴅ ᴀꜱ ᴀᴅᴍɪɴ ɪɴ ʟᴏɢ ɢʀᴏᴜᴘ.\n"
                f"   ➤ ᴇʀʀᴏʀ : {e}"
            )
            return False

        # ꜱᴛᴏʀᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴍᴇᴛᴀ ᴅᴀᴛᴀ
        client.id       = client.me.id
        client.name     = client.me.mention
        client.username = client.me.username

        assistants.append(slot)
        assistantids.append(client.id)

        LOGGER(__name__).info(
            f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} ꜱᴛᴀʀᴛᴇᴅ ᴀꜱ {client.name} ✅"
        )
        return True

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    #  ɢᴇᴛ ꜰɪʀꜱᴛ ᴀᴄᴛɪᴠᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴄʟɪᴇɴᴛ
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def get_active_client(self) -> Optional[Client]:
        """ʀᴇᴛᴜʀɴꜱ ᴛʜᴇ ꜰɪʀꜱᴛ ᴀᴠᴀɪʟᴀʙʟᴇ ᴀᴄᴛɪᴠᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴄʟɪᴇɴᴛ."""
        slot_map = {
            1: self.one,
            2: self.two,
            3: self.three,
            4: self.four,
            5: self.five,
        }
        for slot in assistants:
            client = slot_map.get(slot)
            if client:
                return client
        return None

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    #  ꜱᴛᴀʀᴛ ᴀʟʟ ᴀꜱꜱɪꜱᴛᴀɴᴛꜱ
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def start(self):
        LOGGER(__name__).info("❖ ɪɴɪᴛɪᴀʟɪᴢɪɴɢ ᴀꜱꜱɪꜱᴛᴀɴᴛꜱ...")

        # ᴍᴀᴘ ᴏꜰ ꜱʟᴏᴛ ɴᴜᴍʙᴇʀ → (ꜱᴇꜱꜱɪᴏɴ ꜱᴛʀɪɴɢ, ᴄʟɪᴇɴᴛ)
        slots = [
            (1, config.STRING1, self.one),
            (2, config.STRING2, self.two),
            (3, config.STRING3, self.three),
            (4, config.STRING4, self.four),
            (5, config.STRING5, self.five),
        ]

        started = 0
        for slot, session, client in slots:
            if not session:
                continue  # ꜱʟᴏᴛ ɴᴏᴛ ᴄᴏɴꜰɪɢᴜʀᴇᴅ — ꜱᴋɪᴘ
            if client is None:
                LOGGER(__name__).warning(
                    f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} — ꜱᴇꜱꜱɪᴏɴ ꜱᴇᴛ ʙᴜᴛ ᴄʟɪᴇɴᴛ ɴᴏᴛ ɪɴɪᴛɪᴀʟɪᴢᴇᴅ"
                )
                continue

            success = await self._start_assistant(client, slot)
            if not success:
                LOGGER(__name__).error(
                    f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} — ꜰᴀɪʟᴇᴅ ᴛᴏ ꜱᴛᴀʀᴛ. ᴇxɪᴛɪɴɢ..."
                )
                exit(1)

            started += 1
            # ꜱᴍᴀʟʟ ᴅᴇʟᴀʏ ʙᴇᴛᴡᴇᴇɴ ꜱᴇꜱꜱɪᴏɴꜱ ᴛᴏ ᴀᴠᴏɪᴅ ꜰʟᴏᴏᴅᴡᴀɪᴛ
            await asyncio.sleep(1)

        LOGGER(__name__).info(
            f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛꜱ ʀᴇᴀᴅʏ — {started} ᴀᴄᴛɪᴠᴇ ✅"
        )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    #  ꜱᴛᴏᴘ ᴀʟʟ ᴀꜱꜱɪꜱᴛᴀɴᴛꜱ
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    async def stop(self):
        LOGGER(__name__).info("❖ ꜱᴛᴏᴘᴘɪɴɢ ᴀꜱꜱɪꜱᴛᴀɴᴛꜱ...")

        slots = [
            (1, config.STRING1, self.one),
            (2, config.STRING2, self.two),
            (3, config.STRING3, self.three),
            (4, config.STRING4, self.four),
            (5, config.STRING5, self.five),
        ]

        for slot, session, client in slots:
            if not session or client is None:
                continue
            try:
                await client.stop()
                LOGGER(__name__).info(
                    f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} ꜱᴛᴏᴘᴘᴇᴅ ✅"
                )
            except Exception as e:
                LOGGER(__name__).warning(
                    f"❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ {slot} — ꜱᴛᴏᴘ ᴇʀʀᴏʀ : {e}"
                )

        LOGGER(__name__).info("❖ ᴀʟʟ ᴀꜱꜱɪꜱᴛᴀɴᴛꜱ ꜱʜᴜᴛ ᴅᴏᴡɴ ✅")


# ╔══════════════════════════════════════════════════════════════╗
# ║  ©️ ᴄᴏᴘʏʀɪɢʜᴛ ʀᴇꜱᴇʀᴠᴇᴅ — @ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ ⚚ ᴢᴀʀᴋᴏ ⚚       ║
# ║  🔗 ɢɪᴛʜᴜʙ   : ɢɪᴛʜᴜʙ.ᴄᴏᴍ/ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ/ᴢᴀʀᴋᴏᴍᴜꜱɪᴄʙᴏᴛ  ║
# ║  📢 ᴛᴇʟᴇɢʀᴀᴍ : ᴛ.ᴍᴇ/ᴢᴀʀᴋᴏᴍᴜꜱɪᴄʙᴏᴛ                        ║
# ║  ❤️  ʟᴏᴠᴇ ꜰʀᴏᴍ ᴢᴀʀᴋᴏᴍᴜꜱɪᴄʙᴏᴛ                              ║
# ╚══════════════════════════════════════════════════════════════╝