# ╔══════════════════════════════════════════════════════════════╗
# ║  ©️ ᴄᴏᴘʏʀɪɢʜᴛ (ᴄ) 2026 ⚚ ᴢᴀʀᴋᴏ ⚚ — @ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ           ║
# ║  📍 ʟᴏᴄᴀᴛɪᴏɴ : ꜱᴜᴘᴀᴜʟ, ʙɪʜᴀʀ                                ║
# ║  ⚖️  ᴀʟʟ ʀɪɢʜᴛꜱ ʀᴇꜱᴇʀᴠᴇᴅ                                    ║
# ╠══════════════════════════════════════════════════════════════╣
# ║  ✅ ᴀʟʟᴏᴡᴇᴅ  :  ꜰᴏʀᴋɪɴɢ ꜰᴏʀ ᴘᴇʀꜱᴏɴᴀʟ ʟᴇᴀʀɴɪɴɢ              ║
# ║                  ꜱᴜʙᴍɪᴛᴛɪɴɢ ɪᴍᴘʀᴏᴠᴇᴍᴇɴᴛꜱ ᴠɪᴀ ᴘʀ             ║
# ║  ❌ ɴᴏᴛ ᴀʟʟᴏᴡᴇᴅ: ᴄʟᴀɪᴍɪɴɢ ᴀꜱ ʏᴏᴜʀ ᴏᴡɴ                      ║
# ║                  ʀᴇ-ᴜᴘʟᴏᴀᴅɪɴɢ ᴡɪᴛʜᴏᴜᴛ ᴄʀᴇᴅɪᴛ                ║
# ║                  ꜱᴇʟʟɪɴɢ ᴏʀ ᴄᴏᴍᴍᴇʀᴄɪᴀʟ ᴜꜱᴇ                  ║
# ║  📧 ᴄᴏɴᴛᴀᴄᴛ    : ᴀʟᴛᴜϙ92@ɢᴍᴀɪʟ.ᴄᴏᴍ                         ║
# ╚══════════════════════════════════════════════════════════════╝

import asyncio
import importlib

from pyrogram import idle
from pyrogram.types import BotCommand

try:
    from pytgcalls.exceptions import NoActiveGroupCall
except ImportError:
    try:
        from pytgcalls.exceptions import GroupCallNotFound as NoActiveGroupCall
    except ImportError:
        class NoActiveGroupCall(Exception):
            pass

import config
from ZarkoMusicBot import LOGGER, app, userbot
from ZarkoMusicBot.core.call import Nand
from ZarkoMusicBot.misc import sudo
from ZarkoMusicBot.plugins import ALL_MODULES
from ZarkoMusicBot.utils.database import get_banned_users, get_gbanned
from config import BANNED_USERS


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅꜱ ʟɪꜱᴛ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMMANDS = [
    BotCommand("start",       "❖ ꜱᴛᴀʀᴛ ʙᴏᴛ • ᴛᴏ ꜱᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ"),
    BotCommand("help",        "❖ ʜᴇʟᴘ ᴍᴇɴᴜ • ɢᴇᴛ ᴀʟʟ ᴄᴏᴍᴍᴀɴᴅꜱ ᴀɴᴅ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ"),
    BotCommand("ping",        "❖ ᴘɪɴɢ ʙᴏᴛ • ᴄʜᴇᴄᴋ ᴘɪɴɢ ᴀɴᴅ ꜱʏꜱᴛᴇᴍ ꜱᴛᴀᴛꜱ"),
    BotCommand("play",        "❖ ᴘʟᴀʏ ᴀᴜᴅɪᴏ ᴏɴ ᴠᴄ • ᴛᴏ ᴘʟᴀʏ ᴀɴʏ ᴀᴜᴅɪᴏ ɪɴ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ"),
    BotCommand("vplay",       "❖ ᴘʟᴀʏ ᴠɪᴅᴇᴏ ᴏɴ ᴠᴄ • ᴛᴏ ꜱᴛʀᴇᴀᴍ ᴀɴʏ ᴠɪᴅᴇᴏ ɪɴ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ"),
    BotCommand("playrtmps",   "❖ ᴘʟᴀʏ ʟɪᴠᴇ ᴠɪᴅᴇᴏ • ꜱᴛʀᴇᴀᴍ ʟɪᴠᴇ ᴠɪᴅᴇᴏ ᴄᴏɴᴛᴇɴᴛ"),
    BotCommand("playforce",   "❖ ꜰᴏʀᴄᴇ ᴘʟᴀʏ ᴀᴜᴅɪᴏ • ꜰᴏʀᴄᴇ ᴘʟᴀʏ ᴀɴʏ ᴀᴜᴅɪᴏ ᴛʀᴀᴄᴋ"),
    BotCommand("vplayforce",  "❖ ꜰᴏʀᴄᴇ ᴘʟᴀʏ ᴠɪᴅᴇᴏ • ꜰᴏʀᴄᴇ ᴘʟᴀʏ ᴀɴʏ ᴠɪᴅᴇᴏ ᴛʀᴀᴄᴋ"),
    BotCommand("pause",       "❖ ᴘᴀᴜꜱᴇ ꜱᴛʀᴇᴀᴍ • ᴘᴀᴜꜱᴇ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ꜱᴛʀᴇᴀᴍ"),
    BotCommand("resume",      "❖ ʀᴇꜱᴜᴍᴇ ꜱᴛʀᴇᴀᴍ • ʀᴇꜱᴜᴍᴇ ᴛʜᴇ ᴘᴀᴜꜱᴇᴅ ꜱᴛʀᴇᴀᴍ"),
    BotCommand("skip",        "❖ ꜱᴋɪᴘ ᴛʀᴀᴄᴋ • ꜱᴋɪᴘ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ᴛʀᴀᴄᴋ"),
    BotCommand("end",         "❖ ᴇɴᴅ ꜱᴛʀᴇᴀᴍ • ꜱᴛᴏᴘ ᴛʜᴇ ᴏɴɢᴏɪɴɢ ꜱᴛʀᴇᴀᴍ"),
    BotCommand("stop",        "❖ ꜱᴛᴏᴘ ꜱᴛʀᴇᴀᴍ • ꜱᴛᴏᴘ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ꜱᴛʀᴇᴀᴍ"),
    BotCommand("queue",       "❖ ꜱʜᴏᴡ ϙᴜᴇᴜᴇ • ᴅɪꜱᴘʟᴀʏ ᴛʀᴀᴄᴋ ϙᴜᴇᴜᴇ ʟɪꜱᴛ"),
    BotCommand("auth",        "❖ ᴀᴅᴅ ᴀᴜᴛʜ ᴜꜱᴇʀ • ᴀᴅᴅ ᴜꜱᴇʀ ᴛᴏ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ʟɪꜱᴛ"),
    BotCommand("unauth",      "❖ ʀᴇᴍᴏᴠᴇ ᴀᴜᴛʜ • ʀᴇᴍᴏᴠᴇ ᴜꜱᴇʀ ꜰʀᴏᴍ ᴀᴜᴛʜ ʟɪꜱᴛ"),
    BotCommand("authusers",   "❖ ᴀᴜᴛʜ ʟɪꜱᴛ • ꜱʜᴏᴡ ᴀʟʟ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴜꜱᴇʀꜱ"),
    BotCommand("cplay",       "❖ ᴄʜᴀɴɴᴇʟ ᴀᴜᴅɪᴏ • ᴘʟᴀʏ ᴀᴜᴅɪᴏ ɪɴ ᴄʜᴀɴɴᴇʟ"),
    BotCommand("cvplay",      "❖ ᴄʜᴀɴɴᴇʟ ᴠɪᴅᴇᴏ • ᴘʟᴀʏ ᴠɪᴅᴇᴏ ɪɴ ᴄʜᴀɴɴᴇʟ"),
    BotCommand("cplayforce",  "❖ ᴄʜᴀɴɴᴇʟ ꜰᴏʀᴄᴇ ᴀᴜᴅɪᴏ • ꜰᴏʀᴄᴇ ᴘʟᴀʏ ɪɴ ᴄʜᴀɴɴᴇʟ"),
    BotCommand("cvplayforce", "❖ ᴄʜᴀɴɴᴇʟ ꜰᴏʀᴄᴇ ᴠɪᴅᴇᴏ • ꜰᴏʀᴄᴇ ᴠɪᴅᴇᴏ ɪɴ ᴄʜᴀɴɴᴇʟ"),
    BotCommand("channelplay", "❖ ᴄᴏɴɴᴇᴄᴛ ᴄʜᴀɴɴᴇʟ • ʟɪɴᴋ ɢʀᴏᴜᴘ ᴛᴏ ᴄʜᴀɴɴᴇʟ"),
    BotCommand("loop",        "❖ ʟᴏᴏᴘ ᴍᴏᴅᴇ • ᴇɴᴀʙʟᴇ ᴏʀ ᴅɪꜱᴀʙʟᴇ ʟᴏᴏᴘ"),
    BotCommand("stats",       "❖ ʙᴏᴛ ꜱᴛᴀᴛꜱ • ꜱʜᴏᴡ ʙᴏᴛ ꜱᴛᴀᴛɪꜱᴛɪᴄꜱ"),
    BotCommand("shuffle",     "❖ ꜱʜᴜꜰꜰʟᴇ ϙᴜᴇᴜᴇ • ʀᴀɴᴅᴏᴍɪᴢᴇ ᴛʀᴀᴄᴋ ᴏʀᴅᴇʀ"),
    BotCommand("seek",        "❖ ꜱᴇᴇᴋ ꜰᴏʀᴡᴀʀᴅ • ꜱᴋɪᴘ ᴛᴏ ꜱᴘᴇᴄɪꜰɪᴄ ᴛɪᴍᴇ"),
    BotCommand("seekback",    "❖ ꜱᴇᴇᴋ ʙᴀᴄᴋᴡᴀʀᴅ • ɢᴏ ʙᴀᴄᴋ ᴛᴏ ᴘʀᴇᴠɪᴏᴜꜱ ᴛɪᴍᴇ"),
    BotCommand("song",        "❖ ᴅᴏᴡɴʟᴏᴀᴅ ꜱᴏɴɢ • ɢᴇᴛ ᴍᴘ3 ᴏʀ ᴍᴘ4 ꜰɪʟᴇ"),
    BotCommand("speed",       "❖ ᴀᴅᴊᴜꜱᴛ ꜱᴘᴇᴇᴅ • ᴄʜᴀɴɢᴇ ᴘʟᴀʏʙᴀᴄᴋ ꜱᴘᴇᴇᴅ ɪɴ ɢʀᴏᴜᴘ"),
    BotCommand("cspeed",      "❖ ᴄʜᴀɴɴᴇʟ ꜱᴘᴇᴇᴅ • ᴀᴅᴊᴜꜱᴛ ꜱᴘᴇᴇᴅ ɪɴ ᴄʜᴀɴɴᴇʟ"),
    BotCommand("tagall",      "❖ ᴛᴀɢ ᴀʟʟ • ᴍᴇɴᴛɪᴏɴ ᴇᴠᴇʀʏᴏɴᴇ ɪɴ ɢʀᴏᴜᴘ"),
]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ꜱᴇᴛ ᴄᴏᴍᴍᴀɴᴅꜱ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def setup_bot_commands():
    try:
        await app.set_bot_commands(COMMANDS)
        LOGGER("ZarkoMusicBot").info(
            "❖ ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅꜱ ꜱᴇᴛ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ✅"
        )
    except Exception as e:
        LOGGER("ZarkoMusicBot").error(
            f"❖ ꜰᴀɪʟᴇᴅ ᴛᴏ ꜱᴇᴛ ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅꜱ : {e}"
        )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ᴍᴀɪɴ ɪɴɪᴛ ꜰᴜɴᴄᴛɪᴏɴ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def init():

    # ── ᴀꜱꜱɪꜱᴛᴀɴᴛ ꜱᴇꜱꜱɪᴏɴ ᴄʜᴇᴄᴋ ────────────────────────────────
    if not any([
        config.STRING1,
        config.STRING2,
        config.STRING3,
        config.STRING4,
        config.STRING5,
    ]):
        LOGGER(__name__).error(
            "❖ ɴᴏ ᴀꜱꜱɪꜱᴛᴀɴᴛ ꜱᴇꜱꜱɪᴏɴ ꜰᴏᴜɴᴅ — ᴘʟᴇᴀꜱᴇ ᴀᴅᴅ ᴀᴛ ʟᴇᴀꜱᴛ ᴏɴᴇ STRING_SESSION ɪɴ .ᴇɴᴠ"
        )
        exit(1)

    # ── ꜱᴜᴅᴏ ʟᴏᴀᴅ ────────────────────────────────────────────
    await sudo()

    # ── ʙᴀɴɴᴇᴅ ᴜꜱᴇʀꜱ ʟᴏᴀᴅ ───────────────────────────────────
    try:
        gbanned = await get_gbanned()
        for user_id in gbanned:
            BANNED_USERS.add(user_id)

        banned = await get_banned_users()
        for user_id in banned:
            BANNED_USERS.add(user_id)

        LOGGER("ZarkoMusicBot").info(
            f"❖ ʙᴀɴʟɪꜱᴛ ʟᴏᴀᴅᴇᴅ — {len(BANNED_USERS)} ᴜꜱᴇʀꜱ ʙʟᴏᴄᴋᴇᴅ"
        )
    except Exception as e:
        LOGGER("ZarkoMusicBot").warning(
            f"❖ ʙᴀɴʟɪꜱᴛ ʟᴏᴀᴅ ꜰᴀɪʟᴇᴅ : {e}"
        )

    # ── ʙᴏᴛ ꜱᴛᴀʀᴛ ────────────────────────────────────────────
    await app.start()
    LOGGER("ZarkoMusicBot").info("❖ ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ꜱᴛᴀʀᴛᴇᴅ ✅")

    # ── ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅꜱ ꜱᴇᴛ ─────────────────────────────────────
    await setup_bot_commands()

    # ── ᴘʟᴜɢɪɴ ʟᴏᴀᴅᴇʀ ────────────────────────────────────────
    loaded = 0
    failed = 0
    for module in ALL_MODULES:
        try:
            importlib.import_module("ZarkoMusicBot.plugins" + module)
            loaded += 1
        except Exception as e:
            LOGGER("ZarkoMusicBot.plugins").error(
                f"❖ ꜰᴀɪʟᴇᴅ ᴛᴏ ʟᴏᴀᴅ ᴘʟᴜɢɪɴ [{module}] : {e}"
            )
            failed += 1

    LOGGER("ZarkoMusicBot.plugins").info(
        f"❖ ᴘʟᴜɢɪɴꜱ ʟᴏᴀᴅᴇᴅ — ✅ {loaded} ꜱᴜᴄᴄᴇꜱꜱ  ❌ {failed} ꜰᴀɪʟᴇᴅ"
    )

    # ── ᴀꜱꜱɪꜱᴛᴀɴᴛ ꜱᴛᴀʀᴛ ──────────────────────────────────────
    await userbot.start()
    LOGGER("ZarkoMusicBot").info("❖ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴜꜱᴇʀʙᴏᴛ ꜱᴛᴀʀᴛᴇᴅ ✅")

    # ── ᴘʏᴛɢᴄᴀʟʟꜱ ꜱᴛᴀʀᴛ ─────────────────────────────────────
    await Nand.start()
    LOGGER("ZarkoMusicBot").info("❖ ᴘʏᴛɢᴄᴀʟʟꜱ ɪɴɪᴛɪᴀʟɪᴢᴇᴅ ✅")

    # ── ʟᴏɢ ɢʀᴏᴜᴘ ᴠᴄ ᴄʜᴇᴄᴋ ──────────────────────────────────
    try:
        await Nand.stream_call("https://te.legra.ph/file/29f784eb49d230ab62e9e.mp4")
    except NoActiveGroupCall:
        LOGGER("ZarkoMusicBot").error(
            "❖ ʟᴏɢ ɢʀᴏᴜᴘ/ᴄʜᴀɴɴᴇʟ ᴠɪᴅᴇᴏᴄʜᴀᴛ ɪꜱ ᴏꜰꜰ!\n"
            "   ᴘʟᴇᴀꜱᴇ ᴛᴜʀɴ ᴏɴ ᴛʜᴇ ᴠɪᴅᴇᴏᴄʜᴀᴛ ᴏꜰ ʏᴏᴜʀ ʟᴏɢ ɢʀᴏᴜᴘ/ᴄʜᴀɴɴᴇʟ ᴀɴᴅ ʀᴇꜱᴛᴀʀᴛ.\n"
            "   ꜱᴛᴏᴘᴘɪɴɢ ʙᴏᴛ..."
        )
        exit(1)
    except Exception as e:
        LOGGER("ZarkoMusicBot").warning(
            f"❖ ꜱᴛʀᴇᴀᴍ ᴄᴀʟʟ ᴄʜᴇᴄᴋ ꜱᴋɪᴘᴘᴇᴅ : {e}"
        )

    # ── ᴅᴇᴄᴏʀᴀᴛᴏʀꜱ ───────────────────────────────────────────
    await Nand.decorators()

    # ── ʙᴏᴛ ʀᴇᴀᴅʏ ʟᴏɢ ────────────────────────────────────────
    LOGGER("ZarkoMusicBot").info(
        "\n"
        "╔══════════════════════════════════════════╗\n"
        "║   ⚚  ᴢᴀʀᴋᴏ ᴍᴜꜱɪᴄ ʙᴏᴛ ꜱᴛᴀʀᴛᴇᴅ  ⚚      ║\n"
        "║      ✅  ᴀʟʟ ꜱʏꜱᴛᴇᴍꜱ ʀᴇᴀᴅʏ             ║\n"
        "║   🔗  ɢɪᴛʜᴜʙ.ᴄᴏᴍ/ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ        ║\n"
        "╚══════════════════════════════════════════╝"
    )

    # ── ɪᴅʟᴇ (ᴋᴇᴇᴘ ʙᴏᴛ ʀᴜɴɴɪɴɢ) ──────────────────────────────
    await idle()

    # ── ꜱʜᴜᴛᴅᴏᴡɴ ─────────────────────────────────────────────
    LOGGER("ZarkoMusicBot").info("❖ ꜱʜᴜᴛᴛɪɴɢ ᴅᴏᴡɴ ᴢᴀʀᴋᴏ ᴍᴜꜱɪᴄ ʙᴏᴛ... 🥺")
    await app.stop()
    await userbot.stop()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ᴇɴᴛʀʏ ᴘᴏɪɴᴛ
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(init())


# ╔══════════════════════════════════════════════════════════════╗
# ║  ©️ ᴄᴏᴘʏʀɪɢʜᴛ ʀᴇꜱᴇʀᴠᴇᴅ — @ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ ⚚ ᴢᴀʀᴋᴏ ⚚       ║
# ║  🔗 ɢɪᴛʜᴜʙ   : ɢɪᴛʜᴜʙ.ᴄᴏᴍ/ᴡʜʏ_ɴᴏᴛ_ᴢᴀʀᴋᴏ/ᴢᴀʀᴋᴏᴍᴜꜱɪᴄʙᴏᴛ  ║
# ║  📢 ᴛᴇʟᴇɢʀᴀᴍ : ᴛ.ᴍᴇ/ᴢᴀʀᴋᴏᴍᴜꜱɪᴄʙᴏᴛ                        ║
# ║  ❤️  ʟᴏᴠᴇ ꜰʀᴏᴍ ᴢᴀʀᴋᴏᴍᴜꜱɪᴄʙᴏᴛ                              ║
# ╚══════════════════════════════════════════════════════════════╝