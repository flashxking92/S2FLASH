<p align="center">
  <img src="ZarkoMusicBot/assets/equalizer.svg" width="100%" height="500">
</p><div align="center">
  <img src="https://readme-typing-svg?font=Fira+Code&weight=700&size=34&duration=4500&pause=1000&color=00D9FF&center=true&vCenter=true&width=1600&lines=𝐙𝐚𝐫𝐤𝐨+𝐌𝐮𝐬𝐢𝐜+𝐁𝐨𝐭+—+𝐋𝐢𝐠𝐡𝐭𝐧𝐢𝐧𝐠+𝐅𝐚𝐬𝐭+𝐌𝐮𝐬𝐢𝐜+𝐒𝐭𝐫𝐞𝐚𝐦𝐢𝐧𝐠">
</div>---

<div align="center">⚡ 𝐍𝐨𝐰 𝐑𝐮𝐧𝐧𝐢𝐧𝐠 𝐨𝐧 𝐀𝐏𝐈 ⚡

𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 𝐓𝐢𝐦𝐞: "1-3 seconds" | 𝐒𝐭𝐚𝐛𝐢𝐥𝐢𝐭𝐲: "99.9% Uptime"

"Owner" (https://t.me/Why_not_zarko)

</div>---

🚀 𝐐𝐮𝐢𝐜𝐤 𝐃𝐞𝐩𝐥𝐨𝐲

𝐏𝐥𝐚𝐭𝐟𝐨𝐫𝐦| 𝐃𝐞𝐩𝐥𝐨𝐲| 𝐈𝐧𝐟𝐨
VPS| Manual Setup| Recommended

---

✨ 𝐅𝐞𝐚𝐭𝐮𝐫𝐞𝐬

🎵 High Quality
🔗 Multiple Sources
📋 Playlists
🌐 Multi Language

🎨 Elegant UI
👑 Admin Controls
⚡ Fast Response
🔊 Stable

---

🎯 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬

Command| Description
"/play [song]"| Play music
"/pause"| Pause playback
"/resume"| Resume playback
"/skip"| Skip track
"/stop"| Stop playback
"/playlist"| View playlist
"/song [name]"| Download audio
"/settings"| Bot settings

---

🚀 𝐃𝐞𝐩𝐥𝐨𝐲𝐦𝐞𝐧𝐭 𝐆𝐮𝐢𝐝𝐞

📦 VPS Deployment

Step 1: Update System

sudo apt-get update && sudo apt-get upgrade -y

Step 2: Install Packages

sudo apt-get install python3 python3-pip ffmpeg git screen curl -y

Step 3: Install Node.js (optional)

curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

Step 4: Clone Repo

git clone https://github.com/yourusername/ZarkoMusicBot
cd ZarkoMusicBot

Step 5: Screen Session

screen

Detach: "Ctrl+A + D"
Reattach:

screen -ls
screen -r id

Step 6: Virtual Env

sudo apt-get install python3-venv -y
python3 -m venv venv
source venv/bin/activate

Step 7: Install Requirements

pip install -U pip
pip install -r requirements.txt

Step 8: Setup ENV

nano .env

Fill:

API_ID=
API_HASH=
BOT_TOKEN=
MONGO_DB_URI=
OWNER_ID=
LOG_GROUP_ID=
STRING_SESSION=

Step 9: Start Bot

python3 -m ZarkoMusicBot

---

🔄 Session String

Use Telegram bot:
👉 https://t.me/Sessionbbbot

---

🤔 Common Issues

Issue| Solution
Bot not responding| Check permissions
No sound| Install ffmpeg
Can't join VC| Give admin rights
API error| Check API_ID & HASH
Slow bot| Check VPS

---

📊 Stats

- Fast Response ⚡
- Stable System 🔊
- VPS Optimized 💻

---

🌟 Credits

Original Base: NoxxOP
Modified & Maintained by: Zarko

---

📝 License

MIT License

---

💬 Support

Owner: https://t.me/Why_not_zarko

---

<p align="center">
Made with ❤️ by Zarko
</p><p align="center">
Fast 🚀 Reliable 🔒 High Quality 🎵
</p>