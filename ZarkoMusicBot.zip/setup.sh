#!/bin/bash

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}🚀 ZarkoMusicBot VPS Setup Starting...${NC}"

# -------------------------------
# 1. UPDATE SYSTEM
# -------------------------------
echo -e "${YELLOW}📦 Updating system...${NC}"
sudo apt update

# -------------------------------
# 2. INSTALL BASIC PACKAGES
# -------------------------------
echo -e "${YELLOW}📦 Installing required packages...${NC}"
sudo apt install -y python3 python3-pip python3-venv python3-dev git curl wget ffmpeg redis-server build-essential screen

# -------------------------------
# 3. START REDIS
# -------------------------------
echo -e "${YELLOW}⚡ Starting Redis...${NC}"
sudo systemctl enable redis-server
sudo systemctl start redis-server
echo -e "${GREEN}✅ Redis started on localhost:6379${NC}"

# -------------------------------
# 4. CREATE VIRTUAL ENV
# -------------------------------
echo -e "${YELLOW}🐍 Creating virtual environment...${NC}"
python3 -m venv venv
source venv/bin/activate
echo -e "${GREEN}✅ Virtual environment created!${NC}"

# -------------------------------
# 5. INSTALL PYTHON DEPENDENCIES
# -------------------------------
echo -e "${YELLOW}📚 Installing Python libraries...${NC}"
pip install --upgrade pip setuptools wheel
pip install -U yt-dlp
pip install -r requirements.txt
echo -e "${GREEN}✅ All libraries installed!${NC}"

# -------------------------------
# 6. CREATE .env FILE
# ⚠️  Neeche apni real values bharo
#     = ke baad koi space nahi hona chahiye
# -------------------------------
echo -e "${YELLOW}⚙️ Creating .env file...${NC}"

cat > .env << 'EOF'
API_ID=39219540
API_HASH=21fd45c249c322e2c6d11bfd25baf1c1
BOT_TOKEN=8592205626:AAFSCDe-u-Nj5BUhRJZ-Aflqxowh6JCXGms
OWNER_ID=8305984975
MONGO_DB_URI=mongodb+srv://zarko:admin123@zarko.0sqopcp.mongodb.net/mydb?retryWrites=true&w=majority&appName=Zarko
LOG_GROUP_ID=-1003970175858
SUPPORT_CHANNEL=https://t.me/+yRTIGj74OzFiMjY9
SUPPORT_GROUP=https://t.me/+yRTIGj74OzFiMjY9
REDIS_URL=redis://localhost:6379
STRING_SESSION=BQJWcVQAPDNRTy1APDkNMb6kgz2cLY56hYMsRRx8U3YfiAH9m41Hti1rqHWZzHsglDxrnrjnnUyd6h4m0j5oFW_1Bl6qwkN5dsjo5BdL73-HTJrkVWNtvYSclAD5QpG8uqVTQnplSQg7yUsj9-Vm2tLdmRoWOO01Gt-SOmJrjuFSXPauFucCTOfyyHNZfFUtpcu-bT_satEs3QTADPS8u8Klz1-JTgQA7GpdJoskAzw_j92sUFczbH9a8pFwqc1h4Plj77mCUO-nDy5leYCbGgjviGJkdSaMtWN95MghtYxCb9pw-rlLzi8NacHeCmc5itu9aTQx8cLS6Vn8x5Pd30cbK5K4owAAAAFX3fn6AA
EOF

echo -e "${GREEN}✅ .env file configured successfully!${NC}"

# -------------------------------
# 7. FINAL MESSAGE
# -------------------------------
echo -e "${GREEN}🎉 Setup Complete!${NC}"

echo -e "${YELLOW}👉 Step 1 - .env fill karo:${NC}"
echo -e "${GREEN}   nano .env${NC}"
echo ""
echo -e "${YELLOW}👉 Step 2 - Bot chalao:${NC}"
echo -e "${GREEN}   source venv/bin/activate${NC}"
echo -e "${GREEN}   python3 -m ZarkoMusicBot${NC}"
echo ""
echo -e "${YELLOW}👉 Screen ke saath (logout ke baad bhi chale):${NC}"
echo -e "${GREEN}   screen -S zarko${NC}"
echo -e "${GREEN}   source venv/bin/activate && python3 -m ZarkoMusicBot${NC}"
echo -e "${YELLOW}   Detach: Ctrl+A phir D  |  Wapas: screen -r zarko${NC}"